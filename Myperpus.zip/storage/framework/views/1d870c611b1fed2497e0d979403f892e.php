<nav class="navbar navbar-expand-lg bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('catalog.index')); ?>">
                <img src="<?php echo e(asset('images/MCP.jpg')); ?>" alt="Logo Perpustakaan Multicomp">
            </a>

            <div class="d-flex align-items-center">
                <a href="<?php echo e(route('catalog.all')); ?>" class="btn btn-sm btn-outline-secondary d-lg-none me-3"><i class="bi bi-grid-3x3-gap-fill"></i> Semua</a>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-sm btn-outline-danger"><i class="bi bi-grid-fill"></i> Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-sm btn-outline-danger me-2"><i class="bi bi-person-plus-fill"></i> Mendaftar</a>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-danger"><i class="bi bi-box-arrow-in-right"></i> Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
<?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/layouts/partials/header-public.blade.php ENDPATH**/ ?>