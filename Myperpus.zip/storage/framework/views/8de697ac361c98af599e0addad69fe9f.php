<?php $__env->startSection('content'); ?>
    <div class="max-w-2xl mx-auto">

        
        <div class="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
                <h2 class="text-3xl font-extrabold text-gray-900 tracking-tight">Tambah Jadwal</h2>
                <p class="text-gray-500 mt-1 font-medium">Tentukan hari jaga dan petugas yang bertugas pada hari tersebut.</p>
            </div>
            <a href="<?php echo e(route('admin.superadmin.schedules.index')); ?>" class="inline-flex items-center gap-2 bg-white text-gray-700 border border-gray-200 font-bold py-2.5 px-5 rounded-xl hover:bg-gray-50 transition shadow-sm text-sm">
                <span>⬅️</span> Kembali
            </a>
        </div>

        
        <div class="bg-white rounded-[1.5rem] shadow-sm border border-gray-100 overflow-hidden">
            <div class="bg-slate-900 p-6">
                <h3 class="text-lg font-extrabold text-white">Formulir Jadwal Baru</h3>
            </div>

            <form action="<?php echo e(route('admin.superadmin.schedules.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="p-8 space-y-6">
                    
                    <div>
                        <label for="user_id" class="block text-sm font-bold text-gray-700 mb-2">
                            Pilih Petugas <span class="text-rose-500">*</span>
                        </label>
                        <select name="user_id" id="user_id" required
                                class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-slate-500 focus:ring-slate-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-gray-50 focus:bg-white cursor-pointer font-medium text-gray-700">
                            <option value="">-- Pilih Petugas --</option>
                            <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                    <?php echo e($user->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div>
                        <label for="day_of_week" class="block text-sm font-bold text-gray-700 mb-2">
                            Pilih Hari <span class="text-rose-500">*</span>
                        </label>
                        <select name="day_of_week" id="day_of_week" required
                                class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['day_of_week'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-slate-500 focus:ring-slate-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-gray-50 focus:bg-white cursor-pointer font-medium text-gray-700">
                            <option value="">-- Pilih Hari --</option>
                            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayNumber => $dayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dayNumber); ?>" <?php echo e(old('day_of_week') == $dayNumber ? 'selected' : ''); ?>>
                                    <?php echo e($dayName); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['day_of_week'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div class="bg-gray-50 p-6 flex items-center justify-end gap-4 border-t border-gray-100">
                    <a href="<?php echo e(route('admin.superadmin.schedules.index')); ?>" class="inline-flex items-center justify-center bg-white text-gray-700 border border-gray-200 font-bold py-3 px-8 rounded-xl hover:bg-gray-100 transition shadow-sm text-sm">
                        Batal
                    </a>
                    <button type="submit" class="inline-flex items-center justify-center bg-slate-900 text-white font-bold py-3 px-8 rounded-xl hover:bg-slate-800 transition shadow-sm hover:shadow-md text-sm">
                        Simpan Jadwal
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/admin/superadmin/schedules/create.blade.php ENDPATH**/ ?>