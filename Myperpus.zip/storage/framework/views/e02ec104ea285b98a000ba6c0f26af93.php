<a class="nav-item" href="<?php echo e(route('admin.petugas.genres.index')); ?>">
    <div class="nav-item-main"><span>Kelola Genre</span></div>
    <span class="meta">Data Master</span>
</a>
<a class="nav-item" href="<?php echo e(route('admin.petugas.books.index')); ?>">
    <div class="nav-item-main"><span>Kelola Buku</span></div>
    <span class="meta">Data Master</span>
</a>
<a class="nav-item" href="<?php echo e(route('admin.petugas.verification.index')); ?>">
    <div class="nav-item-main">
        <span>Verifikasi Siswa</span>
        <?php if($pendingStudentsCount > 0): ?>
            <span class="badge"><?php echo e($pendingStudentsCount); ?></span>
        <?php endif; ?>
    </div>
    <span class="meta">Anggota</span>
</a>
<a class="nav-item" href="<?php echo e(route('admin.petugas.teachers.index')); ?>">
    <div class="nav-item-main"><span>Kelola Akun Guru</span></div>
    <span class="meta">Anggota</span>
</a>
<a class="nav-item" href="<?php echo e(route('admin.petugas.approvals.index')); ?>">
    <div class="nav-item-main"><span>Kelola Pengajuan Pinjaman</span></div>
    <span class="meta">Peminjaman</span>
</a>
<a class="nav-item" href="<?php echo e(route('admin.petugas.returns.index')); ?>">
    <div class="nav-item-main"><span>Manajemen Peminjaman</span></div>
    <span class="meta">Pengembalian</span>
</a>
<a class="nav-item" href="<?php echo e(route('admin.petugas.fines.index')); ?>">
    <div class="nav-item-main"><span>Manajemen Denda</span></div>
    <span class="meta">Keuangan</span>
</a>




<a class="nav-item" href="<?php echo e(route('admin.petugas.reports.borrowings.index')); ?>">
    <div class="nav-item-main"><span>Laporan Peminjaman</span></div>
    <span class="meta">Laporan</span>
</a><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/dashboard-partials/petugas.blade.php ENDPATH**/ ?>