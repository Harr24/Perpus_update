<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto">

        
        <div class="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
                <h2 class="text-3xl font-extrabold text-gray-900 tracking-tight">Edit Anggota</h2>
                <p class="text-gray-500 mt-1 font-medium">Perbarui data informasi untuk akun: <span class="font-bold text-slate-800"><?php echo e($member->name); ?></span></p>
            </div>
            <a href="<?php echo e(route('admin.superadmin.members.index')); ?>" class="inline-flex items-center gap-2 bg-white text-gray-700 border border-gray-200 font-bold py-2.5 px-5 rounded-xl hover:bg-gray-50 transition shadow-sm text-sm">
                <span>⬅️</span> Kembali
            </a>
        </div>

        
        <?php if($errors->any()): ?>
            <div class="mb-6 p-5 bg-rose-50 border border-rose-100 rounded-xl">
                <div class="flex items-center gap-2 mb-2 font-bold text-rose-700">
                    <span class="text-xl">⚠️</span> Terdapat Kesalahan:
                </div>
                <ul class="list-disc list-inside text-sm font-medium text-rose-600 pl-7 space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <div class="bg-white rounded-[1.5rem] shadow-sm border border-gray-100 p-8">
            <form action="<?php echo e(route('admin.superadmin.members.update', $member->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                
                
                <div class="mb-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <span>👤</span> Informasi Umum
                    </h3>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        
                        <div>
                            <label for="name" class="block text-sm font-bold text-gray-700 mb-2">Nama Lengkap <span class="text-rose-500">*</span></label>
                            <input type="text" id="name" name="name" value="<?php echo e(old('name', $member->name)); ?>" required
                                   class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-slate-500 focus:ring-slate-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-gray-50 focus:bg-white">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div>
                            <label for="email" class="block text-sm font-bold text-gray-700 mb-2">Alamat Email <span class="text-rose-500">*</span></label>
                            <input type="email" id="email" name="email" value="<?php echo e(old('email', $member->email)); ?>" required
                                   class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-slate-500 focus:ring-slate-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-gray-50 focus:bg-white">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div>
                            <label for="phone_number" class="block text-sm font-bold text-gray-700 mb-2">Nomor Telepon (Opsional)</label>
                            <input type="text" id="phone_number" name="phone_number" value="<?php echo e(old('phone_number', $member->phone_number)); ?>" placeholder="Contoh: 0812..."
                                   class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-slate-500 focus:ring-slate-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-gray-50 focus:bg-white">
                            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div>
                            <label for="role" class="block text-sm font-bold text-gray-700 mb-2">Role Akun <span class="text-rose-500">*</span></label>
                            <select id="role" name="role" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-slate-500 focus:ring-slate-50 focus:ring-4 outline-none transition bg-gray-50 focus:bg-white cursor-pointer font-semibold text-gray-700">
                                <option value="siswa" <?php if(old('role', $member->role) == 'siswa'): echo 'selected'; endif; ?>>Siswa</option>
                                <option value="guru" <?php if(old('role', $member->role) == 'guru'): echo 'selected'; endif; ?>>Guru</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="h-px bg-gray-100 my-8"></div>

                
                
                
                <div class="mb-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <span>🎓</span> Detail Akademik
                    </h3>

                    
                    <div id="student-fields" class="transition-all duration-300 <?php echo e(old('role', $member->role) == 'siswa' ? '' : 'hidden'); ?>">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            
                            <div>
                                <label for="nis" class="block text-sm font-bold text-gray-700 mb-2">NIS <span class="text-rose-500">*</span></label>
                                <input type="text" id="nis" name="nis" value="<?php echo e(old('nis', $member->nis)); ?>"
                                       class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-slate-500 focus:ring-slate-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-gray-50 focus:bg-white font-mono">
                                <?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div>
                                <label for="class" class="block text-sm font-bold text-gray-700 mb-2">Kelas <span class="text-rose-500">*</span></label>
                                <select id="class" name="class" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-slate-500 focus:ring-slate-50 focus:ring-4 outline-none transition bg-gray-50 focus:bg-white cursor-pointer">
                                    <option value="">Pilih Tingkat Kelas</option>
                                    <option value="X" <?php if(old('class', $member->class) == 'X'): echo 'selected'; endif; ?>>X</option>
                                    <option value="XI" <?php if(old('class', $member->class) == 'XI'): echo 'selected'; endif; ?>>XI</option>
                                    <option value="XII" <?php if(old('class', $member->class) == 'XII'): echo 'selected'; endif; ?>>XII</option>
                                    <?php if($member->class == 'Lulus'): ?>
                                        <option value="Lulus" <?php if(true): echo 'selected'; endif; ?> disabled>Alumni / Lulus</option>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div>
                                <label for="major" class="block text-sm font-bold text-gray-700 mb-2">Jurusan <span class="text-rose-500">*</span></label>
                                <select id="major" name="major" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-slate-500 focus:ring-slate-50 focus:ring-4 outline-none transition bg-gray-50 focus:bg-white cursor-pointer">
                                    <option value="">Pilih Jurusan</option>
                                    <?php if(isset($majors)): ?>
                                        <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($major->name); ?>" <?php if(old('major', $member->major) == $major->name): echo 'selected'; endif; ?>>
                                                <?php echo e($major->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                                <?php $__errorArgs = ['major'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    
                    <div id="teacher-fields" class="transition-all duration-300 <?php echo e(old('role', $member->role) == 'guru' ? '' : 'hidden'); ?>">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="subject" class="block text-sm font-bold text-gray-700 mb-2">Mata Pelajaran <span class="text-rose-500">*</span></label>
                                <input type="text" id="subject" name="subject" value="<?php echo e(old('subject', $member->subject)); ?>" placeholder="Contoh: Matematika"
                                       class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-slate-500 focus:ring-slate-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-gray-50 focus:bg-white">
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="h-px bg-gray-100 my-8"></div>

                
                
                
                <div class="mb-8">
                    <h3 class="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <span>⚙️</span> Pengaturan Akun
                    </h3>

                    
                    <div class="mb-6 grid grid-cols-1 md:grid-cols-2">
                        <div>
                            <label for="account_status" class="block text-sm font-bold text-gray-700 mb-2">Status Akun <span class="text-rose-500">*</span></label>
                            <select id="account_status" name="account_status" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-slate-500 focus:ring-slate-50 focus:ring-4 outline-none transition bg-gray-50 focus:bg-white cursor-pointer font-bold text-gray-700">
                                <option value="pending" <?php if(old('account_status', $member->account_status) == 'pending'): echo 'selected'; endif; ?>>Pending (Menunggu Persetujuan)</option>
                                <option value="active" <?php if(old('account_status', $member->account_status) == 'active'): echo 'selected'; endif; ?>>Active (Aktif)</option>
                                <option value="rejected" <?php if(old('account_status', $member->account_status) == 'rejected'): echo 'selected'; endif; ?>>Rejected (Ditolak)</option>
                                <option value="suspended" <?php if(old('account_status', $member->account_status) == 'suspended'): echo 'selected'; endif; ?>>Suspended (Ditangguhkan)</option>
                            </select>
                        </div>
                    </div>

                    
                    <div class="bg-slate-50 rounded-xl border border-slate-100 p-6">
                        <h4 class="font-bold text-gray-900 mb-1">Ubah Password <span class="text-sm font-medium text-gray-500">(Opsional)</span></h4>
                        <p class="text-xs text-gray-500 mb-5">Kosongkan kolom di bawah ini jika Anda tidak ingin mengubah password akun ini.</p>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="password" class="block text-sm font-bold text-gray-700 mb-2">Password Baru</label>
                                <input type="password" id="password" name="password" placeholder="Isi hanya jika ingin ganti password"
                                       class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-slate-500 focus:ring-slate-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-white">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label for="password_confirmation" class="block text-sm font-bold text-gray-700 mb-2">Konfirmasi Password Baru</label>
                                <input type="password" id="password_confirmation" name="password_confirmation" placeholder="Ulangi password baru"
                                       class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-slate-500 focus:ring-slate-50 focus:ring-4 outline-none transition bg-white">
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="flex items-center gap-4 pt-6 border-t border-gray-100">
                    <button type="submit" class="inline-flex items-center justify-center bg-slate-900 text-white font-bold py-3 px-8 rounded-xl hover:bg-slate-800 transition shadow-sm hover:shadow-md">
                        Update Anggota
                    </button>
                    <a href="<?php echo e(route('admin.superadmin.members.index')); ?>" class="inline-flex items-center justify-center bg-white text-gray-700 border border-gray-200 font-bold py-3 px-8 rounded-xl hover:bg-gray-50 transition shadow-sm">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>

    
    <script>
        const roleSelect = document.getElementById('role');
        const studentFields = document.getElementById('student-fields');
        const teacherFields = document.getElementById('teacher-fields');

        // Input elemen
        const nisInput = document.getElementById('nis');
        const classInput = document.getElementById('class');
        const majorInput = document.getElementById('major');
        const subjectInput = document.getElementById('subject');

        function toggleRoleFields() {
            const selectedRole = roleSelect.value;

            if (selectedRole === 'siswa') {
                // Tampilkan Siswa, Sembunyikan Guru
                studentFields.classList.remove('hidden');
                teacherFields.classList.add('hidden');

                // Wajibkan Siswa
                nisInput.required = true;
                classInput.required = true;
                majorInput.required = true;

                // Hapus Wajib Guru
                subjectInput.required = false;

            } else if (selectedRole === 'guru') {
                // Tampilkan Guru, Sembunyikan Siswa
                teacherFields.classList.remove('hidden');
                studentFields.classList.add('hidden');

                // Hapus Wajib Siswa
                nisInput.required = false;
                classInput.required = false;
                majorInput.required = false;

                // Wajibkan Guru
                subjectInput.required = true;
            }
        }

        // Jalankan saat dropdown diubah
        roleSelect.addEventListener('change', toggleRoleFields);

        // Jalankan saat pertama kali dimuat
        document.addEventListener('DOMContentLoaded', toggleRoleFields);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/admin/superadmin/members/edit.blade.php ENDPATH**/ ?>