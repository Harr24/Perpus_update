<?php $__env->startSection('content'); ?>
    <div class="max-w-5xl mx-auto">

        
        <div class="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
                <h2 class="text-3xl font-extrabold text-gray-900 tracking-tight">Profil Saya</h2>
                <p class="text-gray-500 mt-1 font-medium">Kelola informasi data diri dan keamanan akun Anda.</p>
            </div>
            <a href="<?php echo e(route('dashboard')); ?>" class="inline-flex items-center gap-2 bg-white text-gray-700 border border-gray-200 font-bold py-2.5 px-5 rounded-xl hover:bg-gray-50 transition shadow-sm text-sm">
                <span>⬅️</span> Kembali
            </a>
        </div>

        
        <?php if(session('success')): ?>
            <div class="mb-6 p-4 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-xl font-bold flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <span class="text-xl">✅</span> <?php echo e(session('success')); ?>

                </div>
            </div>
        <?php endif; ?>

        
        <?php if(session('error')): ?>
            <div class="mb-6 p-4 bg-rose-50 text-rose-700 border border-rose-100 rounded-xl font-bold flex items-center gap-3">
                <span class="text-xl">⚠️</span> <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <div class="bg-white rounded-[1.5rem] shadow-sm border border-gray-100 overflow-hidden">
            <div class="p-8">
                <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-10">

                        
                        
                        
                        <div class="md:col-span-1 flex flex-col items-center">

                            
                            <div class="w-40 h-40 rounded-full p-1 bg-white border-2 border-gray-100 shadow-md mb-5 relative group overflow-hidden">
                                <img src="<?php echo e($user->profile_photo ? asset('storage/' . $user->profile_photo) : 'https://placehold.co/150x150/6c757d/FFFFFF?text=' . strtoupper(substr($user->name, 0, 1))); ?>"
                                     alt="Foto Profil"
                                     class="w-full h-full object-cover rounded-full">
                            </div>

                            
                            <?php if($user->profile_photo): ?>
                                
                                <button type="button" onclick="confirmDeletePhoto()" class="w-full inline-flex items-center justify-center gap-2 bg-rose-50 text-rose-600 font-bold py-2.5 px-4 rounded-xl hover:bg-rose-100 transition border border-rose-100 text-sm">
                                    <span>🗑️</span> Hapus Foto Saat Ini
                                </button>

                                <div class="mt-4 p-3 bg-amber-50 rounded-xl border border-amber-100 text-xs text-amber-800 leading-relaxed text-center">
                                    <span class="font-bold block mb-1">💡 Ingin ganti foto?</span>
                                    Hapus foto saat ini terlebih dahulu untuk memunculkan tombol upload.
                                </div>
                            <?php else: ?>
                                
                                <div class="w-full">
                                    <label for="profile_photo" class="block text-sm font-bold text-gray-700 mb-2 text-center">
                                        Upload Foto Baru
                                    </label>
                                    <input type="file" id="profile_photo" name="profile_photo"
                                           class="block w-full text-sm text-gray-500 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200 cursor-pointer border border-gray-200 rounded-xl p-1 transition <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                    <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="mt-2 text-xs font-bold text-rose-500 text-center"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        
                        
                        
                        <div class="md:col-span-2 space-y-6">

                            
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">Nama Lengkap</label>
                                <input type="text" value="<?php echo e(old('name', $user->name)); ?>" disabled
                                       class="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-100 text-gray-500 cursor-not-allowed">
                                <p class="mt-1.5 text-xs text-gray-400 font-medium">Nama tidak dapat diubah. Hubungi petugas jika ada kesalahan.</p>
                            </div>

                            
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-2">Alamat Email</label>
                                <input type="email" value="<?php echo e(old('email', $user->email)); ?>" disabled
                                       class="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-100 text-gray-500 cursor-not-allowed">
                                <p class="mt-1.5 text-xs text-gray-400 font-medium">Email bersifat permanen untuk login.</p>
                            </div>

                            
                            <div>
                                <label for="phone_number" class="block text-sm font-bold text-gray-700 mb-2">Nomor WhatsApp</label>
                                <input type="tel" id="phone_number" name="phone_number" value="<?php echo e(old('phone_number', $user->phone_number)); ?>"
                                       placeholder="Contoh: 081234567890"
                                       class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-gray-500 focus:ring-gray-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-gray-50 focus:bg-white">
                                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <?php if($user->role === 'siswa'): ?>
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-bold text-gray-700 mb-2">Kelas</label>
                                        <input type="text" value="<?php echo e(old('class', $user->class)); ?>" disabled class="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-100 text-gray-500 cursor-not-allowed">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-bold text-gray-700 mb-2">Jurusan</label>
                                        <input type="text" value="<?php echo e(old('major', $user->major)); ?>" disabled class="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-100 text-gray-500 cursor-not-allowed truncate">
                                    </div>
                                </div>
                                <p class="text-xs text-gray-400 font-medium -mt-4">Kelas & Jurusan diatur oleh petugas saat kenaikan kelas.</p>
                            <?php endif; ?>

                            <div class="h-px bg-gray-100 my-8"></div>

                            
                            <div>
                                <h3 class="text-lg font-bold text-gray-900 mb-1">Keamanan Akun</h3>
                                <p class="text-sm text-gray-500 mb-5">Kosongkan kolom di bawah ini jika Anda tidak ingin mengubah password.</p>

                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label for="password" class="block text-sm font-bold text-gray-700 mb-2">Password Baru</label>
                                        <input type="password" id="password" name="password"
                                               class="w-full px-4 py-3 rounded-xl border <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-rose-500 ring-rose-50 <?php else: ?> border-gray-200 focus:border-gray-500 focus:ring-gray-50 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> focus:ring-4 outline-none transition bg-gray-50 focus:bg-white">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="mt-2 text-xs font-bold text-rose-500"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <label for="password_confirmation" class="block text-sm font-bold text-gray-700 mb-2">Konfirmasi Password Baru</label>
                                        <input type="password" id="password_confirmation" name="password_confirmation"
                                               class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-gray-500 focus:ring-4 focus:ring-gray-50 outline-none transition bg-gray-50 focus:bg-white">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    
                    <div class="mt-10 pt-6 border-t border-gray-100 text-right">
                        <button type="submit" class="w-full sm:w-auto inline-flex items-center justify-center bg-gray-900 text-white font-bold py-3 px-8 rounded-xl hover:bg-gray-800 transition shadow-sm hover:shadow-md">
                            Simpan Perubahan
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    
    <form id="delete-photo-form" action="<?php echo e(route('profile.photo.delete')); ?>" method="POST" class="hidden">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>

    <script>
        function confirmDeletePhoto() {
            if (confirm('Apakah Anda yakin ingin menghapus foto profil ini?')) {
                document.getElementById('delete-photo-form').submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/profile/edit.blade.php ENDPATH**/ ?>