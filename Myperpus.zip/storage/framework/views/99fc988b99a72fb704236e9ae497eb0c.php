<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($book->title); ?> - Katalog Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --brand-red: #c62828; }
        body { font-family: 'Inter', sans-serif; background-color: #f8f9fa; }
        .cover-image {
            width: 100%;
            max-width: 300px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .book-synopsis {
            white-space: pre-wrap;
            line-height: 1.6;
            color: #495057;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?php echo e(route('catalog.index')); ?>" style="color: var(--brand-red);">
                Perpustakaan Multicomp
            </a>
            <div>
                 <a href="<?php echo e(route('catalog.index')); ?>" class="btn btn-sm btn-outline-secondary me-2">
                     <i class="bi bi-house-door-fill"></i> Kembali ke Beranda
                 </a>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-sm btn-outline-secondary">Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-danger">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <main class="container my-4">
        
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-lg-5">
                <div class="row">
                    
                    <div class="col-md-4 text-center mb-4 mb-md-0">
                        <img src="<?php echo e($book->cover_image ? asset('storage/' . $book->cover_image) : 'https://placehold.co/300x450/E91E63/FFFFFF?text=No+Cover'); ?>" 
                             class="cover-image" alt="Sampul <?php echo e($book->title); ?>">
                    </div>

                    
                    <div class="col-md-8">
                        <h1 class="h2 fw-bold"><?php echo e($book->title); ?></h1>
                        <p class="text-muted">oleh <?php echo e($book->author); ?></p>
                        <div>
                            <span class="badge bg-danger mb-3"><?php echo e($book->genre->name); ?></span>
                            
                            <?php switch($book->book_type):
                                case ('paket'): ?>
                                    <span class="badge bg-info text-dark mb-3">Buku Paket</span>
                                    <?php break; ?>
                                <?php case ('laporan'): ?>
                                    <span class="badge bg-secondary mb-3">Buku Laporan</span>
                                    <?php break; ?>
                                <?php case ('reguler'): ?>
                                    <span class="badge bg-primary mb-3">Buku Reguler</span>
                                    <?php break; ?>
                                <?php default: ?>
                                    
                            <?php endswitch; ?>
                            </div>

                        
                        
                        <p class="mt-3">
                            <strong>Lokasi Rak:</strong> <?php echo e(optional($book->shelf)->name ?? 'Belum Diatur'); ?>

                        </p>
                        
                        
                        
                        <?php if($book->synopsis): ?>
                            <hr>
                            <h5 class="fw-bold">Sinopsis</h5>
                            <p class="book-synopsis"><?php echo nl2br(e($book->synopsis)); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <hr class="my-4">

                <?php if(auth()->guard()->check()): ?>
                    
                    <?php
                        // Cek HANYA apakah buku ini adalah 'paket'
                        $isBookPackage = ($book->book_type == 'paket');
                    ?>

                    
                    <?php if(Auth::user()->role == 'guru' && $isBookPackage): ?>
                        <div class="card bg-light border-2 border-danger border-opacity-25 mb-4">
                            <div class="card-body">
                                <h3 class="h5 fw-bold text-danger"><i class="bi bi-person-workspace me-2"></i> Pinjam Buku Paket (Khusus Guru)</h3>
                                <p class="small text-muted">Anda dapat meminjam beberapa eksemplar buku ini sekaligus untuk kebutuhan kelas.</p>
                                <form action="<?php echo e(route('borrow.store.bulk')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                                    <div class="row align-items-end">
                                        <div class="col-md-6 mb-3 mb-md-0">
                                            <label for="quantity" class="form-label fw-semibold">Jumlah yang ingin dipinjam:</label>
                                            <input type="number" name="quantity" id="quantity" class="form-control" 
                                                   min="1" max="<?php echo e($book->available_copies_count); ?>" 
                                                   placeholder="Maks: <?php echo e($book->available_copies_count); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="submit" class="btn btn-danger w-100 fw-bold">
                                                <i class="bi bi-box-arrow-down me-2"></i> Ajukan Pinjaman Massal
                                            </button>
                                        </div>
                                    </div>
                                    <div class="form-text mt-2">
                                        Saat ini tersedia <strong><?php echo e($book->available_copies_count); ?></strong> eksemplar untuk dipinjam.
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <h3 class="h5 fw-bold mt-4">Daftar Salinan Buku (Pinjam Satuan)</h3>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Kode Eksemplar</th>
                                    <th>Status</th>
                                    <th style="width: 20%;">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $book->copies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $copy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($copy->book_code); ?></td>
                                        <td>
                                            <?php if($copy->status == 'tersedia'): ?>
                                                <span class="badge bg-success">Tersedia</span>
                                            <?php elseif($copy->status == 'pending'): ?>
                                                <span class="badge bg-warning text-dark">Sedang Diajukan</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Dipinjam</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($copy->status == 'tersedia'): ?>
                                                <form action="<?php echo e(route('borrow.store', $copy)); ?>" method="POST" onsubmit="return confirm('Anda yakin ingin meminjam buku ini?');">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm">Ajukan Pinjaman</button>
                                                </form>
                                            <?php else: ?>
                                                <button class="btn btn-secondary btn-sm" disabled>Tidak Tersedia</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">Tidak ada salinan buku yang tersedia.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                    <div class="alert alert-warning mt-4">
                        Anda harus <a href="<?php echo e(route('login')); ?>" class="alert-link">login</a> atau <a href="<?php echo e(route('register')); ?>" class="alert-link">mendaftar</a> untuk dapat meminjam buku.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/public/catalog/show.blade.php ENDPATH**/ ?>