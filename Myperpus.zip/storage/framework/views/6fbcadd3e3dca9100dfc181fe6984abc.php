<?php if(auth()->user()->role == 'superadmin'): ?>
    <?php echo $__env->make('admin.superadmin.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php elseif(auth()->user()->role == 'petugas'): ?>
    <?php echo $__env->make('admin.petugas.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php elseif(auth()->user()->role == 'guru'): ?>
    <?php echo $__env->make('guru.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php elseif(auth()->user()->role == 'siswa'): ?>
    <?php echo $__env->make('siswa.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/dashboard.blade.php ENDPATH**/ ?>