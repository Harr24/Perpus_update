<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name', 'Perpustakaan Multicomp')); ?></title>

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    
    <style>
        :root {
            --primary-red: #d9534f;
            --primary-red-dark: #c9302c;
            --primary-red-light: #e57373;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f6fa;
            min-height: 100vh;
        }

        /* Top Header */
        .top-navbar {
            background: linear-gradient(135deg, var(--primary-red) 0%, var(--primary-red-dark) 100%);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 1rem 0;
        }

        .logo-circle {
            width: 48px;
            height: 48px;
            background-color: rgba(255,255,255,0.25);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.25rem;
            color: white;
        }

        .navbar-title h1 {
            font-size: 1.5rem;
            font-weight: 600;
            margin: 0;
            line-height: 1.2;
        }

        .navbar-title p {
            font-size: 0.875rem;
            margin: 0;
            opacity: 0.95;
        }

        .btn-logout {
            background-color: white;
            color: var(--primary-red);
            border: none;
            padding: 0.5rem 1.25rem;
            border-radius: 0.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
            text-transform: uppercase;
            font-size: 0.875rem;
        }

        .btn-logout:hover {
            background-color: #f8f9fa;
        }

        .main-wrapper {
            min-height: calc(100vh - 100px);
        }
        
        /* Style Lonceng Notifikasi */
        .notification-dropdown .dropdown-toggle::after {
            display: none;
        }
        .notification-icon {
            position: relative;
            font-size: 1.5rem;
            color: white;
            cursor: pointer;
        }
        .notification-count {
            position: absolute;
            top: -5px;
            right: -8px;
            background-color: #ffc107;
            color: #212529;
            font-size: 0.7rem;
            font-weight: 700;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid var(--primary-red);
        }
        .notification-dropdown .dropdown-menu {
            width: 350px;
            padding: 0;
            border-radius: 0.75rem;
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
            border: 1px solid #dee2e6;
        }
        .notification-header {
            padding: 1rem;
            border-bottom: 1px solid #f0f0f0;
        }
        .notification-list {
            max-height: 400px;
            overflow-y: auto;
        }
        .notification-item {
            display: flex;
            align-items: flex-start;
            padding: 1rem;
            border-bottom: 1px solid #f0f0f0;
            text-decoration: none;
            color: #212529;
            transition: background-color 0.2s ease;
        }
        .notification-item:hover {
            background-color: #f8f9fa;
        }
        .notification-item.unread {
            background-color: #fff9e6;
        }
        .notification-item .icon {
            font-size: 1.25rem;
            margin-right: 1rem;
            color: var(--primary-red);
        }
        .notification-item .message {
            font-size: 0.9rem;
            margin-bottom: 0.25rem;
        }
        .notification-item .time {
            font-size: 0.75rem;
            color: #6c757d;
        }
        .notification-footer {
            display: block;
            text-align: center;
            padding: 0.75rem;
            font-weight: 600;
            color: var(--primary-red);
            text-decoration: none;
        }
    </style>

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <div id="app">
        
        <nav class="top-navbar">
            <div class="container-fluid px-3 px-md-4">
                <div class="d-flex justify-content-between align-items-center">
                    
                    <div class="d-flex align-items-center gap-3">
                        <div class="logo-circle">LP</div>
                        <div class="navbar-title text-white">
                            <?php if(auth()->guard()->check()): ?>
                                <h1>Selamat Datang, <?php echo e(strtok(Auth::user()->name, " ")); ?>!</h1>
                                <p>Dashboard <?php echo e(ucfirst(Auth::user()->role)); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="d-flex align-items-center gap-4">
                        <?php if(auth()->guard()->check()): ?>
                            <span class="user-info d-none d-md-inline text-white fw-semibold">
                                <?php echo e(Auth::user()->name); ?>

                            </span>

                            <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn-logout">LOGOUT</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>

        
        <main class="main-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    
    
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/layouts/app.blade.php ENDPATH**/ ?>