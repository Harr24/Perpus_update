 

<?php $__env->startSection('content'); ?>
<div class="p-4 md:p-8 min-h-screen" style="background-color: #F8F9FA;">

    
    <div class="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
            <h1 class="text-2xl font-extrabold text-gray-800 tracking-tight">Katalog Buku</h1>
            <p class="text-sm text-gray-500 mt-1">Jelajahi koleksi perpustakaan dan temukan bacaanmu hari ini.</p>
        </div>

        
        <form action="<?php echo e(route('siswa.katalog')); ?>" method="GET" class="w-full md:w-1/3">
            <?php if(request('genre')): ?>
                <input type="hidden" name="genre" value="<?php echo e(request('genre')); ?>">
            <?php endif; ?>
            <div class="relative group">
                <div class="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
                    <svg class="w-5 h-5 text-gray-400 group-focus-within:text-indigo-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </div>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="block w-full p-3.5 pl-12 text-sm text-gray-900 border border-gray-200 rounded-2xl bg-white focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500 shadow-sm transition-all outline-none" placeholder="Cari judul buku atau penulis...">
                <button type="submit" class="text-white absolute right-2 bottom-2 top-2 bg-indigo-600 hover:bg-indigo-700 font-semibold rounded-xl text-sm px-5 transition-colors">
                    Cari
                </button>
            </div>
        </form>
    </div>

    
    <div class="flex flex-wrap items-center gap-2 mb-8">
        <span class="text-sm font-semibold text-gray-600 mr-2">Kategori:</span>
        <a href="<?php echo e(route('siswa.katalog', ['search' => request('search')])); ?>"
           class="px-4 py-1.5 rounded-full text-sm font-medium transition-colors <?php echo e(!request('genre') ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'); ?>">
            Semua
        </a>
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('siswa.katalog', ['genre' => $genre->name, 'search' => request('search')])); ?>"
               class="px-4 py-1.5 rounded-full text-sm font-medium transition-colors <?php echo e(request('genre') == $genre->name ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'); ?>">
                <?php echo e($genre->name); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-3xl border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col overflow-hidden group">

                
                <div class="relative aspect-[3/4] overflow-hidden bg-gray-100 p-4">
                    <img src="<?php echo e($book->cover_image ? asset('storage/' . $book->cover_image) : asset('images/default-cover.jpg')); ?>"
                         alt="Cover <?php echo e($book->title); ?>"
                         class="w-full h-full object-cover rounded-xl shadow-sm group-hover:scale-105 transition-transform duration-500">
                </div>

                
                <div class="p-5 flex flex-col flex-grow">
                    
                    <div class="flex items-center gap-2 mb-3 flex-wrap">
                        <span class="bg-indigo-50 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                            <?php echo e($book->genre->name ?? 'UMUM'); ?>

                        </span>
                        <?php if($book->shelf): ?>
                            <span class="bg-gray-100 text-gray-600 text-[10px] font-semibold px-2 py-0.5 rounded border border-gray-200">
                                Rak: <?php echo e($book->shelf->name); ?>

                            </span>
                        <?php endif; ?>
                    </div>

                    
                    <h3 class="text-sm md:text-base font-bold text-gray-800 line-clamp-2 leading-snug mb-1" title="<?php echo e($book->title); ?>">
                        <?php echo e($book->title); ?>

                    </h3>
                    <p class="text-xs text-gray-500 truncate mb-3"><?php echo e($book->author); ?></p>

                    
                    <div class="mt-auto"></div>

                    
                    <div class="mb-4">
                        <?php if($book->available_copies_count > 0): ?>
                            <span class="text-emerald-500 font-bold text-xs tracking-wide">Tersedia <?php echo e($book->available_copies_count); ?></span>
                        <?php else: ?>
                            <span class="text-red-500 font-bold text-xs tracking-wide">Stok Habis</span>
                        <?php endif; ?>
                    </div>

                    
                    <a href="<?php echo e(route('siswa.katalog.show', $book->id)); ?>" class="block w-full py-2.5 px-4 bg-white border-2 border-indigo-50 text-indigo-600 font-semibold text-sm text-center rounded-xl hover:bg-indigo-50 hover:border-indigo-100 transition-colors">
                        Lihat Detail
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full flex flex-col items-center justify-center py-20">
                <div class="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <svg class="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>
                </div>
                <h3 class="text-lg font-bold text-gray-800">Buku tidak ditemukan</h3>
                <p class="text-sm text-gray-500 mt-1">Coba gunakan kata kunci atau kategori lain.</p>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="mt-10">
        <?php echo e($books->links('pagination::tailwind')); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/siswa/katalog.blade.php ENDPATH**/ ?>