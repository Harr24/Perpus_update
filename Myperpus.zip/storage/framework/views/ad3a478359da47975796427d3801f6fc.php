<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Semua Katalog Buku - Perpustakaan Multicomp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --brand-red: #c62828; }
        body { font-family: 'Inter', sans-serif; background-color: #f8f9fa; }
        .book-card { border: 1px solid #dee2e6; display: flex; flex-direction: column; transition: all .2s ease-in-out; border-radius: 8px; overflow: hidden; }
        .book-card:hover { transform: translateY(-5px); box-shadow: 0 8px 20px rgba(0,0,0,0.08); }
        .book-cover { height: 300px; object-fit: cover; width: 100%; }
        .card-body { flex-grow: 1; display: flex; flex-direction: column; }
        .pagination .page-item.active .page-link { background-color: var(--brand-red); border-color: var(--brand-red); }
        .pagination .page-link { color: var(--brand-red); }
        .header-section { background-color: #fff; padding: 2rem 0; border-bottom: 1px solid #eee; }

        .genre-filter-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            border-radius: 12px;
            background-color: #fff;
            border: 1px solid #e9ecef;
            text-decoration: none;
            color: #212529;
            transition: all 0.2s ease-in-out;
            text-align: center;
        }
        .genre-filter-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.07);
        }
        .genre-filter-item.active {
            border-color: var(--brand-red);
            background-color: #fef2f2;
            box-shadow: 0 0 0 3px rgba(198, 40, 40, 0.1);
        }
        
        /* LOGIKA TAMPILAN ICON DI FILTER */
        .genre-code {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, #fce4ec, #f8bbd0);
            color: var(--brand-red);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 0.75rem;
            overflow: hidden; /* Tambahan agar gambar bulat */
            position: relative;
        }
        
        /* Tambahan style untuk gambar di dalam lingkaran filter */
        .genre-code img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?php echo e(route('catalog.index')); ?>" style="color: var(--brand-red);">
                <i class="bi bi-book-half me-2"></i> Perpustakaan Multicomp
            </a>

            <div class="d-flex align-items-center ms-auto"> 
                
                <form action="<?php echo e(route('catalog.all')); ?>" method="GET" class="d-none d-lg-block me-3">
                    <div class="input-group input-group-sm">
                        <input type="search" name="search" class="form-control" placeholder="Cari buku..." value="<?php echo e(request('search')); ?>" aria-label="Cari buku cepat">
                        <button class="btn btn-outline-danger" type="submit"><i class="bi bi-search"></i></button>
                    </div>
                </form>

                
                <a href="<?php echo e(route('catalog.all')); ?>" class="btn btn-sm btn-outline-secondary d-lg-none me-2" aria-label="Cari Buku">
                    <i class="bi bi-search"></i>
                </a>

                
                <a href="<?php echo e(route('catalog.index')); ?>" class="btn btn-sm btn-outline-secondary d-flex align-items-center me-2" title="Kembali ke Beranda">
                    <i class="bi bi-house-door-fill me-1 d-none d-sm-inline"></i> 
                    <span class="d-none d-sm-inline">Beranda</span>
                    <i class="bi bi-house-door-fill d-inline d-sm-none"></i>
                </a>

                
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-sm btn-outline-danger" title="Dashboard">
                         <i class="bi bi-grid-fill d-inline d-sm-none"></i>
                         <span class="d-none d-sm-inline">Dashboard</span>
                    </a>
                <?php else: ?>
                     <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-danger" title="Login">
                         <i class="bi bi-box-arrow-in-right d-inline d-sm-none"></i>
                         <span class="d-none d-sm-inline">Login</span>
                     </a>
                <?php endif; ?>
            </div>
            </div>
    </nav>

    <main>
        <div class="container header-section mb-4">
            <h1 class="display-5 fw-bold text-center">Seluruh Katalog Buku</h1>
            <p class="lead text-muted text-center">Jelajahi, cari, dan saring semua koleksi buku kami.</p>
        </div>

        <div class="container my-4">

            
            <div class="mb-5">
                <h5 class="fw-bold mb-3 text-center">Saring Berdasarkan Kategori</h5>
                <div class="d-flex flex-wrap justify-content-center gap-3">
                    <a href="<?php echo e(route('catalog.all', ['search' => request('search')])); ?>"
                       class="genre-filter-item <?php echo e(!request('genre') ? 'active' : ''); ?>"
                       style="min-width: 120px;">
                        <div class="genre-code" style="background: #e9ecef; color: #495057;">All</div>
                        <div class="small fw-bold">Semua</div>
                    </a>
                    
                    
                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('catalog.all', ['genre' => $genre->name, 'search' => request('search')])); ?>"
                           class="genre-filter-item <?php echo e(request('genre') == $genre->name ? 'active' : ''); ?>"
                           style="min-width: 120px;">
                            
                            <div class="genre-code">
                                <?php if($genre->icon): ?>
                                    
                                    <img src="<?php echo e(asset('storage/' . $genre->icon)); ?>" alt="<?php echo e($genre->name); ?>">
                                <?php else: ?>
                                    
                                    <?php echo e($genre->genre_code); ?>

                                <?php endif; ?>
                            </div>
                            
                            <div class="small fw-bold text-truncate"><?php echo e($genre->name); ?></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <div class="row justify-content-center mb-4">
                <div class="col-md-8">
                    <form action="<?php echo e(route('catalog.all')); ?>" method="GET">
                        <?php if(request('genre')): ?>
                            <input type="hidden" name="genre" value="<?php echo e(request('genre')); ?>">
                        <?php endif; ?>
                        <div class="input-group input-group-lg shadow-sm">
                            <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan judul, penulis..." value="<?php echo e(request('search')); ?>" aria-label="Kolom pencarian katalog">
                            <button class="btn btn-danger" type="submit"><i class="bi bi-search"></i> Cari</button>
                        </div>
                    </form>
                </div>
            </div>

            
            <?php if(request('search') || request('genre')): ?>
                <div class="alert alert-info d-flex justify-content-between align-items-center rounded-3 shadow-sm my-4 p-3">
                    <span class="fw-medium">
                        <i class="bi bi-funnel-fill me-2"></i> Filter Aktif:
                        <?php if(request('search')): ?>
                            Pencarian: <span class="badge bg-danger">"<?php echo e(request('search')); ?>"</span>
                        <?php endif; ?>
                        <?php if(request('genre')): ?>
                            Genre: <span class="badge bg-danger"><?php echo e(request('genre')); ?></span>
                        <?php endif; ?>
                    </span>
                    <a href="<?php echo e(route('catalog.all')); ?>" class="btn btn-outline-danger btn-sm">
                        Hapus Filter &times;
                    </a>
                </div>
            <?php endif; ?>

            
            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4">
                <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col">
                        <?php echo $__env->make('public.catalog.partials._book_card', ['book' => $book], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <div class="alert alert-warning text-center mt-3 p-4 shadow-sm">
                            <h4 class="alert-heading"><i class="bi bi-exclamation-triangle-fill"></i> Maaf, Buku Tidak Ditemukan.</h4>
                            <p class="mb-0">Tidak ada buku yang cocok dengan kriteria filter Anda. Coba kata kunci atau filter lain.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            
            <div class="d-flex justify-content-center mt-5">
                <?php echo e($books->appends(request()->query())->links()); ?>

            </div>
        </div>
    </main>

    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/public/catalog/all_books.blade.php ENDPATH**/ ?>