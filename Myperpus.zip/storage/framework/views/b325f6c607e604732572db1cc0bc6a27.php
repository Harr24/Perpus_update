<div class="flex flex-col h-full bg-white border-r">
    <div class="p-6 border-b">
        <h2 class="text-2xl font-bold text-red-600">Smart Library</h2>
        <p class="text-sm text-gray-500">Menu Navigasi</p>
    </div>

    <nav class="flex-1 overflow-y-auto p-4 space-y-2">
        
        <?php if(Auth::user()->role == 'superadmin'): ?>
            <a href="<?php echo e(route('admin.superadmin.petugas.index')); ?>" class="block p-3 rounded-lg bg-gray-50 hover:bg-red-50 hover:text-red-600 transition">
                <div class="font-bold text-sm">Kelola Akun Petugas</div>
                <div class="text-xs text-gray-500">Manajemen Staf</div>
            </a>
            <a href="<?php echo e(route('admin.superadmin.members.index')); ?>" class="block p-3 rounded-lg bg-gray-50 hover:bg-red-50 hover:text-red-600 transition">
                <div class="font-bold text-sm">Kelola Anggota</div>
                <div class="text-xs text-gray-500">Siswa & Guru</div>
            </a>
            <a href="<?php echo e(route('admin.superadmin.majors.index')); ?>" class="block p-3 rounded-lg bg-gray-50 hover:bg-red-50 hover:text-red-600 transition">
                <div class="font-bold text-sm">Kelola Jurusan</div>
                <div class="text-xs text-gray-500">Manajemen Jurusan</div>
            </a>
            <a href="<?php echo e(route('admin.superadmin.shelves.index')); ?>" class="block p-3 rounded-lg bg-gray-50 hover:bg-red-50 hover:text-red-600 transition">
                <div class="font-bold text-sm">Kelola Rak</div>
                <div class="text-xs text-gray-500">Lokasi & Penempatan Buku</div>
            </a>

            <div class="pt-4 pb-1">
                <span class="text-xs font-bold text-gray-400 uppercase tracking-wider">Sistem & Konten</span>
            </div>
            <a href="<?php echo e(route('admin.superadmin.sliders.index')); ?>" class="block p-3 rounded-lg bg-gray-50 hover:bg-red-50 hover:text-red-600 transition">
                <div class="font-bold text-sm">Kelola Hero Slider</div>
                <div class="text-xs text-gray-500">Tampilan Depan</div>
            </a>
            <a href="<?php echo e(route('admin.superadmin.holidays.index')); ?>" class="block p-3 rounded-lg bg-gray-50 hover:bg-red-50 hover:text-red-600 transition">
                <div class="font-bold text-sm">Manajemen Tanggal Merah</div>
                <div class="text-xs text-gray-500">Atur denda & libur</div>
            </a>
            <a href="<?php echo e(route('admin.superadmin.schedules.index')); ?>" class="block p-3 rounded-lg bg-gray-50 hover:bg-red-50 hover:text-red-600 transition">
                <div class="font-bold text-sm">Kelola Jadwal Piket</div>
                <div class="text-xs text-gray-500">Tampilan Depan</div>
            </a>
            <a href="<?php echo e(route('admin.superadmin.fines.history')); ?>" class="block p-3 rounded-lg bg-gray-50 hover:bg-red-50 hover:text-red-600 transition">
                <div class="font-bold text-sm">Kelola Riwayat Denda</div>
                <div class="text-xs text-gray-500">Keuangan/Laporan</div>
            </a>
        <?php endif; ?>

        <div class="pt-4 pb-1">
            <span class="text-xs font-bold text-gray-400 uppercase tracking-wider">Pengaturan</span>
        </div>
        <a href="<?php echo e(route('profile.edit')); ?>" class="block p-3 rounded-lg bg-gray-50 hover:bg-red-50 hover:text-red-600 transition">
            <div class="font-bold text-sm">Edit Profil Saya</div>
            <div class="text-xs text-gray-500">Akun</div>
        </a>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>