<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto">

        
        <div class="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
                <h2 class="text-3xl font-extrabold text-gray-900 tracking-tight">Detail Anggota</h2>
                <p class="text-gray-500 mt-1 font-medium">Informasi lengkap, statistik, dan riwayat aktivitas peminjaman.</p>
            </div>
            <a href="<?php echo e(route('admin.superadmin.members.index')); ?>" class="inline-flex items-center gap-2 bg-white text-gray-700 border border-gray-200 font-bold py-2.5 px-5 rounded-xl hover:bg-gray-50 transition shadow-sm text-sm">
                <span>⬅️</span> Kembali
            </a>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

            
            
            
            <div class="lg:col-span-1 flex flex-col gap-6">
                <div class="bg-white rounded-[1.5rem] shadow-sm border border-gray-100 overflow-hidden">

                    
                    <div class="p-8 flex flex-col items-center text-center border-b border-gray-100 relative">
                        
                        <div class="absolute top-0 left-0 w-full h-24 bg-slate-50"></div>

                        <div class="relative mb-5 z-10">
                            <?php if($member->profile_photo): ?>
                                <img src="<?php echo e(asset('storage/' . $member->profile_photo)); ?>" alt="<?php echo e($member->name); ?>" class="h-28 w-28 rounded-full object-cover border-4 border-white shadow-md bg-white">
                            <?php else: ?>
                                <div class="h-28 w-28 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 text-4xl font-extrabold border-4 border-white shadow-md">
                                    <?php echo e(strtoupper(substr($member->name, 0, 2))); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <h2 class="text-xl font-extrabold text-gray-900"><?php echo e($member->name); ?></h2>
                        <p class="text-sm font-medium text-gray-500 mb-4"><?php echo e($member->email); ?></p>

                        <div class="flex flex-wrap justify-center gap-2">
                             <span class="px-3 py-1 rounded-xl text-xs font-bold uppercase tracking-wider
                                <?php if($member->role == 'siswa'): ?> bg-indigo-50 text-indigo-700 border border-indigo-100
                                <?php elseif($member->role == 'guru'): ?> bg-rose-50 text-rose-700 border border-rose-100
                                <?php else: ?> bg-slate-50 text-slate-700 border border-slate-200 <?php endif; ?>">
                                <?php echo e($member->role); ?>

                            </span>
                             <span class="px-3 py-1 rounded-xl text-xs font-bold uppercase tracking-wider border
                                <?php echo e($member->account_status == 'active' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-amber-50 text-amber-700 border-amber-100'); ?>">
                                <?php echo e($member->account_status); ?>

                            </span>
                        </div>
                    </div>

                    
                    <div class="p-6 bg-white">
                        <h3 class="text-xs font-extrabold text-gray-400 uppercase tracking-wider mb-4">Informasi Tambahan</h3>

                        <div class="space-y-4">
                            <div class="flex justify-between items-center pb-3 border-b border-gray-100 border-dashed">
                                <span class="text-sm font-medium text-gray-500">No. WhatsApp</span>
                                <span class="text-sm font-bold text-gray-900"><?php echo e($member->phone_number ?? '-'); ?></span>
                            </div>

                            <?php if($member->role == 'siswa'): ?>
                                <div class="flex justify-between items-center pb-3 border-b border-gray-100 border-dashed">
                                    <span class="text-sm font-medium text-gray-500">NIS</span>
                                    <span class="text-sm font-bold text-gray-900 font-mono bg-gray-100 px-2 py-0.5 rounded"><?php echo e($member->nis ?? '-'); ?></span>
                                </div>
                                <div class="flex justify-between items-center pb-3 border-b border-gray-100 border-dashed">
                                    <span class="text-sm font-medium text-gray-500">Kelas & Jurusan</span>
                                    <span class="text-sm font-bold text-gray-900 text-right">
                                        <?php if($member->class == 'Lulus'): ?>
                                            <span class="text-[10px] bg-slate-800 text-white px-2.5 py-1 rounded-lg uppercase tracking-wider shadow-sm">Alumni</span>
                                        <?php elseif(!empty($member->class) && !empty($member->major)): ?>
                                            <?php echo e($member->class); ?> - <?php echo e($member->major); ?>

                                        <?php elseif(!empty($member->class_name)): ?>
                                            <?php echo e($member->class_name); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </span>
                                </div>
                            <?php endif; ?>

                            <?php if($member->role == 'guru'): ?>
                                <div class="flex justify-between items-center pb-3 border-b border-gray-100 border-dashed">
                                    <span class="text-sm font-medium text-gray-500">Mata Pelajaran</span>
                                    <span class="text-sm font-bold text-gray-900 text-right"><?php echo e($member->subject ?? '-'); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="mt-8">
                            <a href="<?php echo e(route('admin.superadmin.members.edit', $member->id)); ?>" class="flex items-center justify-center w-full py-3 px-4 bg-slate-900 text-white rounded-xl shadow-sm text-sm font-bold hover:bg-slate-800 transition">
                                Edit Data Anggota
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            
            
            
            <div class="lg:col-span-2 flex flex-col gap-6">

                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">

                    
                    <div class="bg-white p-6 rounded-[1.5rem] shadow-sm border border-gray-100 flex items-center gap-5">
                        <div class="w-16 h-16 rounded-full bg-indigo-50 flex items-center justify-center shrink-0 text-indigo-600">
                            
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25" />
                            </svg>
                        </div>
                        <div>
                            <p class="text-xs font-extrabold text-gray-400 uppercase tracking-wider mb-1">Total Peminjaman</p>
                            <h3 class="text-3xl font-extrabold text-gray-900"><?php echo e($totalLoans ?? 0); ?></h3>
                        </div>
                    </div>

                    
                    <div class="bg-white p-6 rounded-[1.5rem] shadow-sm border border-gray-100 flex items-center gap-5">
                        <?php $hasActive = ($activeLoans ?? 0) > 0; ?>
                        <div class="w-16 h-16 rounded-full <?php echo e($hasActive ? 'bg-amber-50 text-amber-600' : 'bg-emerald-50 text-emerald-600'); ?> flex items-center justify-center shrink-0">
                            <?php if($hasActive): ?>
                                
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                </svg>
                            <?php else: ?>
                                
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8">
                                  <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                </svg>
                            <?php endif; ?>
                        </div>
                        <div>
                            <p class="text-xs font-extrabold text-gray-400 uppercase tracking-wider mb-1">Sedang Dipinjam</p>
                            <h3 class="text-3xl font-extrabold <?php echo e($hasActive ? 'text-amber-600' : 'text-emerald-600'); ?>"><?php echo e($activeLoans ?? 0); ?></h3>
                        </div>
                    </div>
                </div>

                
                <div class="bg-white rounded-[1.5rem] shadow-sm border border-gray-100 overflow-hidden flex-1 flex flex-col">
                    <div class="px-6 py-5 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
                        <h3 class="text-lg font-extrabold text-gray-900 flex items-center gap-2">
                            
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5 text-gray-600">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                            </svg>
                            Riwayat Aktivitas
                        </h3>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead class="bg-white border-b border-gray-100">
                                <tr>
                                    <th class="px-6 py-4 text-xs font-extrabold text-gray-500 uppercase tracking-wider">Info Buku</th>
                                    <th class="px-6 py-4 text-xs font-extrabold text-gray-500 uppercase tracking-wider">Pinjam</th>
                                    <th class="px-6 py-4 text-xs font-extrabold text-gray-500 uppercase tracking-wider">Kembali</th>
                                    <th class="px-6 py-4 text-xs font-extrabold text-gray-500 uppercase tracking-wider">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                <?php $__empty_1 = true; $__currentLoopData = $borrowings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrowing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="hover:bg-gray-50/80 transition duration-200">
                                        <td class="px-6 py-4">
                                            <div class="flex items-center gap-4">
                                                
                                                <div class="w-10 h-14 bg-gray-100 rounded-lg overflow-hidden shrink-0 border border-gray-200">
                                                    <?php if(isset($borrowing->bookCopy->book->cover_image)): ?>
                                                        <img src="<?php echo e(asset('storage/' . $borrowing->bookCopy->book->cover_image)); ?>" class="w-full h-full object-cover">
                                                    <?php else: ?>
                                                        <div class="w-full h-full flex items-center justify-center text-[9px] font-bold text-gray-400">NO COVER</div>
                                                    <?php endif; ?>
                                                </div>
                                                <div>
                                                    <h4 class="text-sm font-bold text-gray-900 line-clamp-1" title="<?php echo e($borrowing->bookCopy->book->title ?? '-'); ?>">
                                                        <?php echo e($borrowing->bookCopy->book->title ?? 'Buku Dihapus'); ?>

                                                    </h4>
                                                    <p class="text-xs font-bold text-gray-500 font-mono mt-0.5">
                                                        Kode: <?php echo e($borrowing->bookCopy->book_code ?? '-'); ?>

                                                    </p>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 text-sm font-medium text-gray-700 whitespace-nowrap">
                                            <?php echo e(\Carbon\Carbon::parse($borrowing->borrowed_at)->format('d M Y')); ?>

                                        </td>
                                        <td class="px-6 py-4 text-sm font-medium text-gray-700 whitespace-nowrap">
                                            <?php if($borrowing->returned_at): ?>
                                                <?php echo e(\Carbon\Carbon::parse($borrowing->returned_at)->format('d M Y')); ?>

                                            <?php else: ?>
                                                <span class="text-gray-400">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <?php if(in_array($borrowing->status, ['pending', 'dipinjam'])): ?>
                                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-50 text-amber-700 text-xs font-bold border border-amber-100">
                                                    <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span> Dipinjam
                                                </span>
                                            <?php elseif($borrowing->status == 'returned'): ?>
                                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-100">
                                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Kembali
                                                </span>
                                            <?php elseif($borrowing->status == 'rejected'): ?>
                                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-rose-50 text-rose-700 text-xs font-bold border border-rose-100">
                                                    <span class="w-1.5 h-1.5 rounded-full bg-rose-500"></span> Ditolak
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-gray-100 text-gray-700 text-xs font-bold border border-gray-200">
                                                    <span class="w-1.5 h-1.5 rounded-full bg-gray-500"></span> <?php echo e(ucfirst($borrowing->status)); ?>

                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="px-6 py-12 text-center">
                                            <div class="flex flex-col items-center justify-center text-gray-400">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-12 h-12 mb-3">
                                                  <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                                </svg>
                                                <h3 class="text-base font-bold text-gray-900">Belum ada aktivitas</h3>
                                                <p class="text-sm text-gray-500 mt-1">Anggota ini belum pernah meminjam buku.</p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/admin/superadmin/members/show.blade.php ENDPATH**/ ?>