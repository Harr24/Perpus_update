


<?php if(isset($borrowingInfo) && $borrowingInfo !== null): ?>

    
    
    
    <?php if($displayMode == 'grouped'): ?> 
        <h3 class="widget-title" id="widgetTitle">
            📚 Buku Paket yang Sedang Dipinjam
        </h3>
        <div class="borrowing-list-stack">
            
            <?php $__currentLoopData = $borrowingInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="active-borrowing-card">
                    
                    <?php if($group->book && $group->book->cover_image): ?>
                        <img src="<?php echo e(Storage::url($group->book->cover_image)); ?>" alt="Cover <?php echo e($group->book->title); ?>" class="borrowed-cover">
                    <?php else: ?>
                        <div class="borrowed-cover-placeholder">
                            <span>Tidak ada cover</span>
                        </div>
                    <?php endif; ?>
                    
                    <div class="borrowed-info">
                        
                        <h4><?php echo e($group->book->title ?? 'Judul Tidak Ditemukan'); ?></h4>
                        
                        
                        <div class="borrowed-meta">
                            <span>Jumlah:</span>
                            <strong><?php echo e($group->count); ?> eksemplar</strong>
                        </div>
                        
                        
                        
                        <?php if($group->earliest_borrowed instanceof \Carbon\Carbon): ?>
                        <div class="borrowed-meta">
                            <span>Dipinjam Sejak:</span>
                            <strong><?php echo e($group->earliest_borrowed->format('d M Y')); ?></strong>
                        </div>
                        <?php endif; ?>
                        <?php if($group->latest_due instanceof \Carbon\Carbon): ?>
                        <div class="borrowed-meta">
                            <span>Jatuh Tempo Hingga:</span>
                            <strong><?php echo e($group->latest_due->format('d M Y')); ?></strong>
                        </div>
                         <?php elseif(is_string($group->latest_due)): ?> 
                         <div class="borrowed-meta">
                            <span>Jatuh Tempo Hingga:</span>
                            <strong><?php echo e(\Carbon\Carbon::parse($group->latest_due)->format('d M Y')); ?></strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <a href="<?php echo e(route('borrow.history')); ?>" class="btn-widget-full">Lihat Rincian & Riwayat Peminjaman</a>

    
    
    
    <?php elseif($displayMode == 'individual'): ?> 
         <h3 class="widget-title" id="widgetTitle">
            📖 Buku yang Sedang Dipinjam (<?php echo e($borrowingInfo->count()); ?>)
        </h3>
         <div class="borrowing-list-stack">
            
            <?php $__currentLoopData = $borrowingInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeBorrowing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="active-borrowing-card">
                    <?php if($activeBorrowing->bookCopy && $activeBorrowing->bookCopy->book && $activeBorrowing->bookCopy->book->cover_image): ?>
                        <img src="<?php echo e(Storage::url($activeBorrowing->bookCopy->book->cover_image)); ?>" alt="Cover <?php echo e($activeBorrowing->bookCopy->book->title); ?>" class="borrowed-cover">
                    <?php else: ?>
                        <div class="borrowed-cover-placeholder">
                            <span>Tidak ada cover</span>
                        </div>
                    <?php endif; ?>
                    <div class="borrowed-info">
                        <h4><?php echo e($activeBorrowing->bookCopy->book->title ?? 'Judul Tidak Ditemukan'); ?></h4>
                        <div class="borrowed-meta">
                            <span>Kode Eksemplar:</span>
                            <strong><?php echo e($activeBorrowing->bookCopy->book_code ?? 'N/A'); ?></strong>
                        </div>
                        <div class="borrowed-meta">
                            <span>Tanggal Pinjam:</span>
                            <strong><?php echo e($activeBorrowing->borrowed_at->format('d M Y')); ?></strong>
                        </div>
                        <div class="borrowed-meta">
                            <span>Jatuh Tempo:</span>
                            
                            <?php if($activeBorrowing->due_date instanceof \Carbon\Carbon): ?>
                            <strong><?php echo e($activeBorrowing->due_date->format('d M Y')); ?></strong>
                            <?php elseif(is_string($activeBorrowing->due_date)): ?>
                            <strong><?php echo e(\Carbon\Carbon::parse($activeBorrowing->due_date)->format('d M Y')); ?></strong>
                            <?php else: ?>
                            <strong>N/A</strong>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
         <a href="<?php echo e(route('borrow.history')); ?>" class="btn-widget-full">Lihat Semua Riwayat Peminjaman</a>
    <?php endif; ?>




<?php else: ?> 
    <h3 class="widget-title" id="widgetTitle">💡 Kutipan Hari Ini</h3>
    <blockquote class="quote-card">
        <p>"<?php echo e($quote['content'] ?? 'Membaca adalah jendela dunia.'); ?>"</p>
        <footer>— <?php echo e($quote['author'] ?? 'Pribahasa'); ?></footer>
    </blockquote>
    <a href="<?php echo e(route('catalog.index')); ?>" class="btn-widget-full btn-start-reading">
        Mulai Membaca Buku
    </a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/dashboard-partials/status-widget.blade.php ENDPATH**/ ?>