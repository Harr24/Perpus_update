<?php $__env->startSection('content'); ?>
    <div class="max-w-3xl mx-auto">
        
        <div class="mb-8">
            <h2 class="text-3xl font-extrabold text-gray-900 tracking-tight">Edit Materi</h2>
            <p class="text-gray-500 mt-1 font-medium">Perbarui informasi, tautan, atau ubah status tayang materi ini.</p>
        </div>

        
        <div class="bg-white rounded-[1.5rem] shadow-sm border border-gray-100 p-8">
            <form action="<?php echo e(route('guru.materials.update', $material)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="mb-6">
                    <label for="title" class="block text-sm font-bold text-gray-700 mb-2">
                        Judul Materi <span class="text-rose-500">*</span>
                    </label>
                    <input type="text" name="title" id="title" value="<?php echo e($material->title); ?>" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-rose-500 focus:ring-4 focus:ring-rose-50 outline-none transition bg-gray-50 focus:bg-white" placeholder="Contoh: Modul Matematika Bab 1" required>
                </div>

                
                <div class="mb-6">
                    <label for="link_url" class="block text-sm font-bold text-gray-700 mb-2">
                        URL Link Materi <span class="text-rose-500">*</span>
                    </label>
                    <input type="url" name="link_url" id="link_url" value="<?php echo e($material->link_url); ?>" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-rose-500 focus:ring-4 focus:ring-rose-50 outline-none transition bg-gray-50 focus:bg-white" placeholder="https://youtube.com/..." required>
                </div>

                
                <div class="mb-6">
                    <label for="description" class="block text-sm font-bold text-gray-700 mb-2">
                        Deskripsi (Opsional)
                    </label>
                    <textarea name="description" id="description" rows="4" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-rose-500 focus:ring-4 focus:ring-rose-50 outline-none transition bg-gray-50 focus:bg-white resize-none" placeholder="Berikan sedikit penjelasan tentang materi ini..."><?php echo e($material->description); ?></textarea>
                </div>

                
                <div class="mb-8 p-4 bg-gray-50 rounded-xl border border-gray-200 flex items-center gap-3 hover:bg-rose-50/50 transition cursor-pointer">
                    <input type="checkbox" name="is_active" id="is_active" value="1" class="w-5 h-5 accent-rose-600 cursor-pointer" <?php echo e($material->is_active ? 'checked' : ''); ?>>
                    <label for="is_active" class="text-sm font-bold text-gray-700 cursor-pointer select-none flex-1">
                        Aktifkan Materi
                        <span class="block text-xs font-normal text-gray-500 mt-0.5">Jika dicentang, materi ini akan terlihat oleh siswa di halaman publik.</span>
                    </label>
                </div>

                
                <div class="flex items-center gap-4 pt-6 border-t border-gray-100">
                    <button type="submit" class="inline-flex items-center justify-center bg-rose-600 text-white font-bold py-3 px-8 rounded-xl hover:bg-rose-700 transition shadow-sm hover:shadow-md">
                        Update Materi
                    </button>
                    <a href="<?php echo e(route('guru.materials.index')); ?>" class="inline-flex items-center justify-center bg-white text-gray-700 border border-gray-200 font-bold py-3 px-8 rounded-xl hover:bg-gray-50 transition shadow-sm">
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/guru/materials/edit.blade.php ENDPATH**/ ?>