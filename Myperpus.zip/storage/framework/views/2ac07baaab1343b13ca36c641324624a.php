<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 fw-bold mb-1">Profil Saya</h1>
                    <p class="text-muted mb-0">Informasi akun Anda di sistem perpustakaan.</p>
                </div>
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-arrow-left me-1"></i> Kembali ke Dashboard
                </a>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="card shadow-sm border-0">
                <div class="card-body p-4 p-md-5">
                    <div class="row align-items-center">
                        <div class="col-md-4 text-center mb-4 mb-md-0">
                            
                            <img src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="Foto Profil" class="img-fluid rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
                        </div>
                        <div class="col-md-8">
                            <h3 class="fw-bold"><?php echo e(Auth::user()->name); ?></h3>
                            <p class="text-muted">
                                <?php if(Auth::user()->role === 'siswa'): ?>
                                    Siswa
                                <?php elseif(Auth::user()->role === 'guru'): ?>
                                    Guru
                                <?php else: ?>
                                    Anggota
                                <?php endif; ?>
                            </p>
                            <hr>

                            
                            <?php if(Auth::user()->role === 'siswa'): ?>
                            <div class="row mb-2">
                                <div class="col-sm-4 fw-semibold text-muted">NISN</div>
                                <div class="col-sm-8">: <?php echo e(Auth::user()->nis ?: '-'); ?></div>
                            </div>
                            
                            
                            <div class="row mb-2">
                                <div class="col-sm-4 fw-semibold text-muted">Kelas</div>
                                <div class="col-sm-8">: <?php echo e(Auth::user()->class_info ?? '-'); ?></div>
                            </div>
                            <?php endif; ?>

                            
                            <?php if(Auth::user()->role === 'guru'): ?>
                            <div class="row mb-2">
                                <div class="col-sm-4 fw-semibold text-muted">Mata Pelajaran</div>
                                <div class="col-sm-8">: <?php echo e(Auth::user()->subject ?: '-'); ?></div>
                            </div>
                            <?php endif; ?>
                            
                            
                            <div class="row mb-2">
                                <div class="col-sm-4 fw-semibold text-muted">Email</div>
                                <div class="col-sm-8">: <?php echo e(Auth::user()->email); ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-sm-4 fw-semibold text-muted">Nomor WhatsApp</div>
                                <div class="col-sm-8">: <?php echo e(Auth::user()->phone_number ?: '-'); ?></div>
                            </div>

                            <div class="mt-4">
                                
                                <?php if(Route::has('profile.edit')): ?>
                                <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-danger">
                                    <i class="bi bi-pencil-square me-2"></i> Edit Profil
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/profile/show.blade.php ENDPATH**/ ?>