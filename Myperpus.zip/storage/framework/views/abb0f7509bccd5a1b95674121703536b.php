<div class="bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md p-4 flex justify-between items-center w-full">
    
    <div class="flex items-center gap-4 min-w-0">
        <div class="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center font-bold text-lg shadow-inner overflow-hidden flex-shrink-0">
            <?php if(Auth::user()->profile_photo): ?>
                <img src="<?php echo e(Storage::url(Auth::user()->profile_photo)); ?>" alt="Foto Profil" class="w-full h-full object-cover">
            <?php else: ?>
                <?php echo e(strtoupper(substr(Auth::user()->name, 0, 2))); ?>

            <?php endif; ?>
        </div>
        <div class="flex flex-col leading-tight overflow-hidden">
            <h1 class="m-0 text-lg font-semibold truncate">Selamat Datang, <?php echo e(strtok(Auth::user()->name, " ")); ?>!</h1>
            <p class="m-0 text-sm opacity-90 truncate">Dashboard <?php echo e(ucfirst(Auth::user()->role)); ?></p>
        </div>
    </div>

    <div class="flex items-center gap-3 flex-shrink-0">
        <div id="clock" class="hidden md:block font-semibold bg-white/10 px-3 py-2 rounded-full text-sm min-w-[80px] text-center">
            00:00:00
        </div>
        <div class="hidden md:flex items-center gap-2 bg-white/10 px-3 py-2 rounded-full font-semibold text-sm">
            <?php echo e(ucfirst(Auth::user()->role)); ?>

        </div>
        <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline m-0">
            <?php echo csrf_field(); ?>
            <button type="submit" class="bg-white text-red-600 hover:bg-red-50 hover:text-red-700 shadow px-4 py-2 rounded-lg font-semibold text-sm transition">
                LOGOUT
            </button>
        </form>
    </div>
</div>

<script>
    function updateClock() {
        const now = new Date();
        const options = { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
        const timeString = now.toLocaleTimeString('id-ID', options);
        const clockElement = document.getElementById('clock');
        if (clockElement) {
            clockElement.textContent = timeString.replace(/\./g, ':');
        }
    }
    setInterval(updateClock, 1000);
    updateClock();
</script><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/layouts/header.blade.php ENDPATH**/ ?>