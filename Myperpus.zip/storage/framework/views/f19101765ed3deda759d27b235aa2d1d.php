<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Materi Belajar - Perpustakaan Multicomp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --brand-red: #c62828; }
        body { font-family: 'Inter', sans-serif; background-color: #f8f9fa; }
        
        /* ==========================================================
          --- REVISI: Menggunakan style 'material-card' Anda ---
          Saya akan gunakan class 'material-card' yang sudah Anda buat
          untuk kartu baru dengan thumbnail.
          ==========================================================
        */
        .material-card {
            border: 1px solid #dee2e6;
            transition: all .2s ease-in-out;
            border-radius: 8px;
            overflow: hidden;
            text-decoration: none;
            color: #212529;
            background-color: #fff; 
        }
        .material-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
        }
        
        /* Style untuk pagination agar sesuai tema */
        .pagination .page-item.active .page-link {
            background-color: var(--brand-red);
            border-color: var(--brand-red);
            color: white; /* Warna teks putih */
        }
        .pagination .page-link {
            color: var(--brand-red);
             box-shadow: none !important; /* Hilangkan shadow focus bootstrap */
        }
         .pagination .page-link:hover {
             background-color: #f8d7da; /* Warna hover lebih lembut */
             border-color: #f5c2c7;
         }
         .pagination .page-item.disabled .page-link {
             color: #6c757d;
             background-color: #e9ecef;
             border-color: #dee2e6;
         }
         
        /* Style untuk gambar thumbnail agar pas */
         .material-card-img {
            height: 200px;
            object-fit: cover; /* Membuat gambar mengisi area tanpa distorsi */
         }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold me-auto" href="<?php echo e(route('catalog.index')); ?>" style="color: var(--brand-red);">
                <i class="bi bi-book-half me-2"></i> Perpustakaan Multicomp
            </a>

            <div class="d-flex align-items-center">
                <a href="<?php echo e(route('catalog.index')); ?>" class="btn btn-sm btn-outline-secondary d-none d-md-flex align-items-center me-2">
                    <i class="bi bi-house-door-fill me-1"></i>
                    <span class="d-none d-lg-inline">Beranda</span>
                </a>
                 <a href="<?php echo e(route('catalog.index')); ?>" class="btn btn-sm btn-outline-secondary d-md-none me-2" aria-label="Kembali ke Beranda">
                    <i class="bi bi-house-door-fill"></i>
                </a>
                
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-sm btn-outline-danger" title="Dashboard">
                         <i class="bi bi-grid-fill d-inline d-sm-none"></i>
                         <span class="d-none d-sm-inline">Dashboard</span>
                    </a>
                <?php else: ?>
                     <a href="<?php echo e(route('login')); ?>" class="btn btn-sm btn-danger" title="Login">
                         <i class="bi bi-box-arrow-in-right d-inline d-sm-none"></i>
                         <span class="d-none d-sm-inline">Login</span>
                     </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <main class="container py-5">
        <div class="text-center mb-5">
            <h1 class="fw-bold display-5">Materi Belajar</h1>
            <p class="lead text-muted">Akses semua materi tambahan yang dibagikan oleh para guru.</p>
        </div>

        
        <div class="card card-body mb-5 shadow-sm border-0">
            <form action="<?php echo e(route('catalog.materials.all')); ?>" method="GET" class="row g-3 align-items-end">
                <div class="col-md-6">
                    <label for="search" class="form-label fw-semibold">Cari Judul Materi</label>
                    <input type="search" name="search" id="search" class="form-control" value="<?php echo e(request('search')); ?>" placeholder="Contoh: Sejarah Kemerdekaan">
                </div>
                <div class="col-md-4">
                    <label for="teacher" class="form-label fw-semibold">Filter Berdasarkan Guru</label>
                    <select name="teacher" id="teacher" class="form-select">
                        <option value="">Semua Guru</option>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($teacher->id); ?>" <?php echo e(request('teacher') == $teacher->id ? 'selected' : ''); ?>>
                                <?php echo e($teacher->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2 d-grid">
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-search me-1"></i> Cari
                    </button>
                </div>
            </form>
        </div>

        
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php $__empty_1 = true; $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col">
                    <a href="<?php echo e($material->link_url); ?>" target="_blank" rel="noopener noreferrer" class="material-card h-100 d-flex flex-column">
                        
                        
                        <img src="<?php echo e($material->thumbnail_url); ?>" class="card-img-top material-card-img" alt="Thumbnail <?php echo e($material->title); ?>">
                        
                        <div class="card-body d-flex flex-column p-4">
                            <h5 class="card-title fw-bold mb-2"><?php echo e(Str::limit($material->title, 50)); ?></h5>
                            
                            <?php if($material->description): ?>
                                <p class="card-text text-muted small mb-3">
                                    <?php echo e(Str::limit($material->description, 100)); ?>

                                </p>
                            <?php endif; ?>
                            
                            
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        Oleh: <?php echo e($material->user->name); ?>

                                    </small>
                                    
                                    
                                    <?php if(str_contains($material->link_url, 'youtu')): ?>
                                        <span class="badge bg-danger">
                                            <i class="bi bi-play-circle-fill me-1"></i> Video
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">
                                            <i class="bi bi-link-45deg me-1"></i> Link
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-warning text-center">
                        <h5 class="alert-heading">Materi Tidak Ditemukan</h5>
                        <p class="mb-0">Tidak ada materi yang cocok dengan kriteria pencarian Anda. Coba kata kunci atau filter yang berbeda.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        
        
        <?php if($materials->hasPages()): ?>
        <div class="d-flex justify-content-center mt-5">
            
            <?php echo e($materials->links()); ?>

        </div>
        <?php endif; ?>
        

    </main>

    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/public/catalog/all_materials.blade.php ENDPATH**/ ?>