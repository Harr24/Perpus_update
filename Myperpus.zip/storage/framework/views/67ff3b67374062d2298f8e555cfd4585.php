<div class="card h-100 book-card shadow-sm">

    
    
    
    <?php if($book->cover_image): ?>
        <img src="<?php echo e(asset('storage/' . $book->cover_image)); ?>" 
             class="card-img-top book-cover" 
             alt="Sampul <?php echo e($book->title); ?>" 
             loading="lazy"
             style="object-fit: cover;"
             onerror="this.onerror=null;this.src='<?php echo e(asset('images/Tome.png')); ?>';this.style.objectFit='scale-down';this.style.padding='2rem';this.style.backgroundColor='#f4f4f4';">
    <?php else: ?>
        
        <img src="<?php echo e(asset('images/Tome.png')); ?>" 
             class="card-img-top book-cover" 
             alt="Gambar default buku" 
             loading="lazy"
             style="object-fit: scale-down; padding: 2rem; background-color: #f4f4f4;">
    <?php endif; ?>
    
    
    

    <div class="card-body d-flex flex-column">
        <h6 class="card-title fw-bold text-truncate" title="<?php echo e($book->title); ?>"><?php echo e($book->title); ?></h6>
        <p class="card-text small text-muted mb-2"><?php echo e($book->author); ?> (<?php echo e($book->publication_year ?? 'N/A'); ?>)</p>

        <div class="mt-auto">
            
            <p class="mb-2 small">
                <span class="fw-bold"><?php echo e($book->available_copies_count); ?></span> / <?php echo e($book->copies_count); ?> Tersedia
            </p>

            <?php if($book->available_copies_count === 0): ?>
                <span class="badge bg-secondary">Stok Habis</span>
            <?php elseif($book->available_copies_count > 0 && $book->available_copies_count < 4): ?>
                <span class="badge bg-warning text-dark">Stok Rendah!</span>
            <?php else: ?>
                <span class="badge bg-success">Tersedia</span>
            <?php endif; ?>

            <!-- ========================================================== -->
            <!-- ===== PERBAIKAN: Menampilkan SEMUA Tipe Buku ===== -->
            <!-- ========================================================== -->
            <?php switch($book->book_type):
                case ('reguler'): ?>
                    <span class="badge bg-primary">Buku Reguler</span>
                    <?php break; ?>
                <?php case ('paket'): ?>
                    <span class="badge bg-info text-dark">Buku Paket</span>
                    <?php break; ?>
                <?php case ('laporan'): ?>
                    <span class="badge bg-secondary">Buku Laporan</span>
                    <?php break; ?>
            <?php endswitch; ?>
            <!-- ========================================================== -->

        </div>
    </div>

    <div class="card-footer bg-white border-0 p-2">
        <div class="d-grid gap-2">
            <?php if($book->available_copies_count > 0): ?>
                
                <a href="<?php echo e(route('catalog.show', $book)); ?>" class="btn btn-sm btn-danger fw-bold">
                    <i class="bi bi-book-fill"></i> Lihat & Pinjam
                </a>
            <?php else: ?>
                
                <button class="btn btn-sm btn-secondary" disabled>Stok Habis</button>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/public/catalog/partials/_book_card.blade.php ENDPATH**/ ?>