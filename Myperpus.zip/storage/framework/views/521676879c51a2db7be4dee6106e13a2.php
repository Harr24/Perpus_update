<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Katalog Buku - Perpustakaan Multicomp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
        :root {
            --brand-red: #c62828;
            --brand-red-hover: #b71c1c;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f9fa;
            overflow-x: hidden;
        }

        /* NAVBAR */
        .navbar { transition: all 0.3s ease; }
        .navbar-brand { font-size: 1.25rem; transition: transform 0.3s ease; }
        .navbar-brand:hover { transform: scale(1.05); }
        .navbar-brand img { height: 50px !important; transition: all 0.3s ease; }
        @media (max-width: 768px) { .navbar-brand img { height: 40px !important; } }

        /* Button animations */
        .btn { transition: all 0.3s ease; position: relative; overflow: hidden; }
        .btn::before { content: ''; position: absolute; top: 50%; left: 50%; width: 0; height: 0; border-radius: 50%; background: rgba(255, 255, 255, 0.2); transform: translate(-50%, -50%); transition: width 0.6s, height 0.6s; }
        .btn:hover::before { width: 300px; height: 300px; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }

        /* HERO SLIDER */
        .hero-slider .carousel-item { height: 60vh !important; max-height: 580px !important; min-height: 400px !important; position: relative; background-size: cover; background-position: center; animation: kenBurns 20s ease infinite; }
        .hero-slider .carousel-item img { display: none; }
        @keyframes kenBurns { 0% { background-position: center 45%; } 50% { background-position: center 55%; } 100% { background-position: center 45%; } }
        .hero-slider .carousel-item::after { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(to right, rgba(0,0,0,0.65) 30%, rgba(0,0,0,0.1) 70%); z-index: 1; }
        .hero-slider .carousel-caption { position: absolute; top: 50%; transform: translateY(-50%); bottom: auto; left: 10%; right: auto; width: 50%; text-align: left; z-index: 2; padding-top: 0; padding-bottom: 0; }
        .hero-slider .carousel-caption h1 { animation: fadeInUp 1s ease; text-shadow: 2px 2px 8px rgba(0,0,0,0.7); font-size: 2.75rem; font-weight: 700; }
        .hero-slider .carousel-caption p { animation: fadeInUp 1.2s ease; font-size: 1.1rem; }
        .hero-slider .carousel-caption .btn { animation: fadeInUp 1.4s ease; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        @media (max-width: 768px) { .hero-slider .carousel-item { height: 50vh !important; min-height: 300px !important; } .hero-slider .carousel-caption { left: 8%; width: 80%; } .hero-slider .carousel-caption h1 { font-size: 1.75rem; } .hero-slider .carousel-caption p { display: none; } }
        .carousel-control-prev-icon, .carousel-control-next-icon { background-color: rgba(198, 40, 40, 0.8); padding: 15px; border-radius: 50%; transition: all 0.3s ease; }
        .carousel-control-prev-icon:hover, .carousel-control-next-icon:hover { background-color: rgba(198, 40, 40, 1); transform: scale(1.1); }

        /* SEARCH BAR */
        .search-container { position: relative; }
        .search-container .input-group { transition: all 0.3s ease; }
        .search-container .form-control:focus { box-shadow: 0 0 0 0.25rem rgba(198, 40, 40, 0.25); border-color: var(--brand-red); }

        /* SUBJECT CARDS (GENRE) - UPDATE UNTUK ICON */
        .subject-card { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 1.5rem 1rem; border-radius: 12px; background-color: #fff; border: 2px solid #e9ecef; text-decoration: none; color: #212529; transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); position: relative; overflow: hidden; }
        .subject-card::before { content: ''; position: absolute; top: 0; left: -100%; width: 100%; height: 100%; background: linear-gradient(90deg, transparent, rgba(198, 40, 40, 0.1), transparent); transition: left 0.5s ease; }
        .subject-card:hover::before { left: 100%; }
        .subject-card:hover { transform: translateY(-8px) scale(1.05); box-shadow: 0 12px 30px rgba(198, 40, 40, 0.2); border-color: var(--brand-red); }

        .subject-code {
            width: 70px; height: 70px;
            border-radius: 50%;
            background: linear-gradient(135deg, #fce4ec, #f8bbd0);
            color: var(--brand-red);
            display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem; font-weight: 700;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(198, 40, 40, 0.2);
            overflow: hidden; /* Tambahan agar gambar tidak keluar */
            position: relative;
        }
        /* Tambahan style untuk gambar di dalam lingkaran */
        .subject-code img { width: 100%; height: 100%; object-fit: cover; }

        .subject-card:hover .subject-code { transform: rotate(360deg) scale(1.1); background: linear-gradient(135deg, var(--brand-red), #e53935); color: white; }
        .subject-name { transition: all 0.3s ease; }
        .subject-card:hover .subject-name { color: var(--brand-red); transform: scale(1.05); }

        /* BOOK CARDS */
        .book-card, .material-card { border: 1px solid #dee2e6; display: flex; flex-direction: column; transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); border-radius: 12px; overflow: hidden; position: relative; }
        .book-card::before, .material-card::before { content: ''; position: absolute; top: -50%; left: -50%; width: 200%; height: 200%; background: radial-gradient(circle, rgba(198, 40, 40, 0.1) 0%, transparent 70%); opacity: 0; transition: opacity 0.5s ease; }
        .book-card:hover::before, .material-card:hover::before { opacity: 1; }
        .book-card:hover, .material-card:hover { transform: translateY(-10px) scale(1.02); box-shadow: 0 15px 35px rgba(0,0,0,0.15); border-color: var(--brand-red); }
        .book-cover { height: 300px; object-fit: cover; width: 100%; transition: transform 0.5s ease; }
        .book-card:hover .book-cover { transform: scale(1.1); }
        .card-body { flex-grow: 1; display: flex; flex-direction: column; position: relative; z-index: 1; }
        .card-footer { border-top: 1px dashed #e9ecef !important; transition: background-color 0.3s ease; }
        .book-card:hover .card-footer { background-color: #fff5f5; }

        /* GAMIFIKASI PERINGKAT */
        .borrower-card { border: none; transition: all 0.4s ease; border-radius: 16px; position: relative; overflow: visible; background: #fff; }
        .borrower-card:hover { transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0,0,0,0.1) !important; }
        .reader-avatar-container { position: relative; width: 90px; height: 90px; margin: 0 auto 15px; }
        .avatar { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; border: 4px solid #f8f9fa; transition: all 0.3s ease; }
        .avatar-placeholder { display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #fce4ec, #f8bbd0); color: #c62828; font-size: 2rem; font-weight: 600; width: 100%; height: 100%; border-radius: 50%; border: 4px solid #f8f9fa;}
        .rank-badge { position: absolute; top: -5px; right: -5px; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 1rem; box-shadow: 0 2px 5px rgba(0,0,0,0.2); z-index: 10; border: 2px solid #fff; }
        .rank-1 .avatar, .rank-1 .avatar-placeholder { border-color: #FFD700; box-shadow: 0 0 15px rgba(255, 215, 0, 0.5); }
        .rank-1 .rank-badge { background: linear-gradient(45deg, #FFD700, #FDB931); }
        .rank-1 .card-title { color: #d4af37 !important; font-weight: 800; text-shadow: 0px 0px 1px rgba(212, 175, 55, 0.3); }
        .rank-2 .avatar, .rank-2 .avatar-placeholder { border-color: #C0C0C0; }
        .rank-2 .rank-badge { background: linear-gradient(45deg, #E0E0E0, #B0B0B0); }
        .rank-3 .avatar, .rank-3 .avatar-placeholder { border-color: #CD7F32; }
        .rank-3 .rank-badge { background: linear-gradient(45deg, #CD7F32, #A0522D); }

        /* SECTION HEADERS */
        .display-6 { position: relative; display: inline-block; }
        .display-6::after { content: ''; position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%); width: 0; height: 4px; background: linear-gradient(90deg, var(--brand-red), #e53935); transition: width 0.5s ease; }
        [data-aos].aos-animate .display-6::after { width: 100px; }

        /* MATERIAL CARDS */
        .material-card .card-body { transition: all 0.3s ease; }
        .material-card:hover .card-body { background-color: #fff8f8; }
        .material-card i { transition: transform 0.3s ease; }
        .material-card:hover i { transform: rotate(-10deg) scale(1.1); }
        .material-card-img { height: 180px; object-fit: cover; }

        /* RESPONSIVE */
        @media (max-width: 768px) { .book-cover { height: 250px; } .navbar-brand img { height: 40px !important; } }
        @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-10px); } }
        .btn-lg { animation: float 3s ease-in-out infinite; }
        html { scroll-behavior: smooth; }

        /* INFO BLOCK */
        .info-block { display: flex; align-items: flex-start; gap: 1.25rem; }
        .info-icon { flex-shrink: 0; width: 60px; height: 60px; border-radius: 12px; background-color: #fff5f5; display: flex; align-items: center; justify-content: center; color: var(--brand-red); font-size: 1.75rem; box-shadow: 0 4px 10px rgba(198, 40, 40, 0.1); transition: all 0.3s ease; }
        .info-block:hover .info-icon { transform: scale(1.1); background-color: var(--brand-red); color: #fff; }
        .info-text { flex-grow: 1; }
        .info-title { font-size: 1.25rem; font-weight: 700; color: var(--brand-red); margin-top: 0; margin-bottom: 0.25rem; }
        .info-text p { font-size: 1rem; line-height: 1.6; color: #333; margin-bottom: 0; }

        /* JADWAL PIKET */
        .border-primary-red { border-color: var(--brand-red) !important; }
        .bg-primary-red { background-color: var(--brand-red) !important; color: #fff !important; }
    </style>
</head>
<body>
    <?php echo $__env->make('layouts.partials.header-public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main>
        
        <?php if(isset($heroSliders) && $heroSliders->isNotEmpty()): ?>
        <div id="heroCarousel" class="carousel slide hero-slider" data-bs-ride="carousel" data-bs-interval="5000">
            <div class="carousel-indicators">
                <?php $__currentLoopData = $heroSliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?php echo e($index); ?>" class="<?php echo e($index === 0 ? 'active' : ''); ?>" aria-current="<?php echo e($index === 0 ? 'true' : 'false'); ?>" aria-label="Slide <?php echo e($index + 1); ?>"></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="carousel-inner">
                <?php $__currentLoopData = $heroSliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>" style="background-image: url('<?php echo e(asset('storage/' . $slider->image_path)); ?>');">
                        <div class="carousel-caption">
                            <?php if($slider->title): ?>
                                <h1 class="display-4 fw-bold mb-3"><?php echo e($slider->title); ?></h1>
                            <?php endif; ?>
                            <?php if($slider->description): ?>
                                <p class="lead d-none d-md-block"><?php echo e($slider->description); ?></p>
                            <?php endif; ?>
                            <?php if($slider->link_url): ?>
                                <a href="<?php echo e($slider->link_url); ?>" class="btn btn-danger btn-lg mt-3" target="_blank" rel="noopener noreferrer">
                                    BACA SELENGKAPNYA <i class="bi bi-arrow-right ms-2"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if($heroSliders->count() > 1): ?>
                <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev"><span class="carousel-control-prev-icon" aria-hidden="true"></span><span class="visually-hidden">Previous</span></button>
                <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next"><span class="carousel-control-next-icon" aria-hidden="true"></span><span class="visually-hidden">Next</span></button>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        
        <div class="bg-white py-5 shadow-sm">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-5" data-aos="fade-right">
                        <img src="<?php echo e(asset('images/orangsekolah.png')); ?>" alt="Ilustrasi siswi membaca buku" class="img-fluid rounded-3 shadow-lg" style="width: 100%; height: auto; max-height: 450px; object-fit: cover;">
                    </div>
                    <div class="col-lg-7" data-aos="fade-left" data-aos-delay="100">
                        <h2 class="fw-bold display-6" style="color: var(--brand-red);">Apa itu MyMulticompLibrary?</h2>
                        <p class="lead text-muted mt-3">Ini adalah web perpustakaan digital resmi SMK Multicomp Depok.</p>
                        <p style="font-size: 1.1rem; line-height: 1.7;">Kami hadir untuk membawa perpustakaan ke dalam genggaman Anda. Di era digital ini, <strong>pentingnya membaca</strong> menjadi semakin krusial untuk membuka wawasan.</p>
                        <a href="#search-section" class="btn btn-danger btn-lg mt-3"><i class="bi bi-search me-2"></i> Mulai Cari Buku</a>
                    </div>
                </div>
            </div>
        </div>

        
        <section class="container my-5">
            <div class="row">
                <div class="col-12 text-center mb-4" data-aos="fade-up">
                    <h2 class="fw-bold display-6">Jadwal Piket Perpustakaan</h2>
                    <p class="lead text-muted">Temui petugas yang siap membantu Anda setiap harinya.</p>
                </div>
            </div>
            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayNumber => $dayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $isToday = ($dayNumber == $todayDayOfWeek);
                        $schedules = $schedulesByDay->get($dayNumber);
                    ?>
                    <div class="col-12 col-sm-6 col-md-6 col-lg mb-4">
                        <div class="card h-100 shadow-sm <?php echo e($isToday ? 'border-primary-red' : ''); ?>" style="<?php echo e($isToday ? 'border-width: 2px;' : ''); ?>">
                            <div class="card-header <?php echo e($isToday ? 'bg-primary-red' : ''); ?>">
                                <h6 class="m-0 font-weight-bold text-center"><?php echo e($dayName); ?></h6>
                            </div>
                            <div class="card-body" style="min-height: 150px; font-size: 0.9rem;">
                                <?php if($schedules && $schedules->isNotEmpty()): ?>
                                    <ul class="list-unstyled mb-0">
                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="mb-2">
                                                <strong><?php echo e($schedule->user->name); ?></strong><br>
                                                <small class="text-muted">Petugas</small>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php else: ?>
                                    <div class="text-center text-muted d-flex flex-column justify-content-center h-100">
                                        <i class="bi bi-cup-hot" style="font-size: 1.5rem;"></i>
                                        <small class="mt-2">Jadwal Kosong</small>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        
        <div class="container py-5" id="search-section">
            <div class="text-center mb-5" data-aos="fade-up">
                <h2 class="fw-bold display-6">Jelajahi Berdasarkan Kategori</h2>
                <p class="lead text-muted">Temukan koleksi buku favorit Anda berdasarkan subjek.</p>
            </div>
            <div class="row justify-content-center mb-5" data-aos="fade-up" data-aos-delay="100">
                <div class="col-md-8">
                    <div class="search-container">
                        <form action="<?php echo e(route('catalog.all')); ?>" method="GET">
                            <div class="input-group input-group-lg shadow-sm">
                                <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan judul, penulis..." value="<?php echo e(request('search')); ?>" aria-label="Kolom pencarian katalog">
                                <button class="btn btn-danger" type="submit"><i class="bi bi-search"></i> Cari</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-6 g-3" data-aos="fade-up" data-aos-delay="200">
                <?php $__empty_1 = true; $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col">
                        <a href="<?php echo e(route('catalog.all', ['genre' => $genre->name])); ?>" class="subject-card h-100">
                            <div class="subject-code">
                                <?php if($genre->icon): ?>
                                    
                                    <img src="<?php echo e(asset('storage/' . $genre->icon)); ?>" alt="<?php echo e($genre->name); ?>">
                                <?php else: ?>
                                    
                                    <?php echo e(strtoupper(substr($genre->name, 0, 2))); ?>

                                <?php endif; ?>
                            </div>
                            <div class="subject-name small fw-bolder text-truncate"><?php echo e($genre->name); ?></div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center"><p class="text-muted">Genre belum ditambahkan.</p></div>
                <?php endif; ?>
            </div>
            

        </div>

        
        <div class="bg-white py-5 shadow-sm" data-aos="fade-up">
            <div class="container">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="fw-bold mb-0 text-danger"><i class="bi bi-heart-fill me-2"></i> 10 Buku Favorit</h3>
                </div>
                <?php if($favoriteBooks->isNotEmpty()): ?>
                    <div id="favoriteBooksCarousel" class="carousel slide">
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $favoriteBooks->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                                    <div class="row row-cols-2 row-cols-md-4 g-4">
                                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col"><?php echo $__env->make('public.catalog.partials._book_card', ['book' => $book], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#favoriteBooksCarousel" data-bs-slide="prev"><span class="carousel-control-prev-icon" aria-hidden="true"></span><span class="visually-hidden">Previous</span></button>
                        <button class="carousel-control-next" type="button" data-bs-target="#favoriteBooksCarousel" data-bs-slide="next"><span class="carousel-control-next-icon" aria-hidden="true"></span><span class="visually-hidden">Next</span></button>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info text-center">Belum ada data untuk menentukan buku favorit.</div>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="bg-white py-5 mt-5 shadow-sm" data-aos="fade-up">
             <div class="container">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="fw-bold mb-0"><i class="bi bi-arrow-down-up me-2"></i> 10 Buku Terbaru</h3>
                    <a href="<?php echo e(route('catalog.all', ['sort' => 'latest'])); ?>" class="btn btn-outline-danger btn-sm">Lihat Semua Buku <i class="bi bi-arrow-right"></i></a>
                </div>
                <div class="row row-cols-2 row-cols-md-4 row-cols-lg-5 g-4">
                    <?php $__empty_1 = true; $__currentLoopData = $latestBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col">
                            <?php echo $__env->make('public.catalog.partials._book_card', ['book' => $book], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center"><div class="alert alert-warning">Belum ada buku baru.</div></div>
                    <?php endif; ?>
                </div>
                <div class="text-center mt-5">
                     <a href="<?php echo e(route('catalog.all')); ?>" class="btn btn-lg btn-danger shadow-lg"><i class="bi bi-grid-3x3-gap-fill me-2"></i> Lihat Semua Buku di Katalog</a>
                </div>
            </div>
        </div>

        
        <?php if(isset($learningMaterials) && $learningMaterials->isNotEmpty()): ?>
        <div class="container py-5 mt-5" data-aos="fade-up">
            <div class="text-center mb-5">
                <h2 class="fw-bold display-6">Materi Belajar Terbaru</h2>
                <p class="lead text-muted">Akses materi tambahan yang dibagikan oleh para guru.</p>
            </div>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
                <?php $__currentLoopData = $learningMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <a href="<?php echo e($material->link_url); ?>" target="_blank" rel="noopener noreferrer" class="material-card h-100 d-flex flex-column text-decoration-none">
                            <img src="<?php echo e($material->thumbnail_url ?? asset('images/default-material.jpg')); ?>" class="card-img-top material-card-img" alt="Thumbnail <?php echo e($material->title); ?>">
                            <div class="card-body d-flex flex-column p-3">
                                <h5 class="card-title fw-bold mb-2 text-dark" style="font-size: 1rem;"><?php echo e(Str::limit($material->title, 45)); ?></h5>
                                <?php if($material->description): ?>
                                    <p class="card-text text-muted small mb-3" style="font-size: 0.85rem;"><?php echo e(Str::limit($material->description, 70)); ?></p>
                                <?php endif; ?>
                                <div class="mt-auto">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted" style="font-size: 0.8rem;">Oleh: <?php echo e($material->user->name); ?></small>
                                        <?php if(str_contains($material->link_url, 'youtu')): ?>
                                            <span class="badge bg-danger"><i class="bi bi-play-circle-fill me-1"></i> Video</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary"><i class="bi bi-link-45deg me-1"></i> Link</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center mt-5">
                <a href="<?php echo e(route('catalog.materials.all')); ?>" class="btn btn-outline-danger"><i class="bi bi-collection-fill me-2"></i> Lihat Semua Materi Belajar</a>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if(isset($topBorrowers) && $topBorrowers->count() > 0): ?>
        <section class="top-borrowers-section mt-5 py-5" data-aos="fade-up">
            <div class="container">
                <div class="text-center mb-5">
                    <h2 class="fw-bold display-6"><?php echo e($semesterTitle ?? 'Peminjam Teratas'); ?></h2>
                    <div class="h-1 w-20 bg-red-500 mx-auto mt-2 mb-4 rounded"></div>
                    <p class="lead text-muted">Apresiasi bagi para penikmat koleksi kami.</p>
                </div>

                <div class="row g-4 justify-content-center">
                    <?php $__currentLoopData = $topBorrowers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $rankClass = '';
                            $rankIcon = '';

                            if ($loop->iteration == 1) {
                                $rankClass = 'rank-1'; // Emas
                                $rankIcon = '<i class="bi bi-trophy-fill text-warning"></i>';
                            } elseif ($loop->iteration == 2) {
                                $rankClass = 'rank-2'; // Perak
                                $rankIcon = '2';
                            } elseif ($loop->iteration == 3) {
                                $rankClass = 'rank-3'; // Perunggu
                                $rankIcon = '3';
                            }
                        ?>

                        <div class="col-md-6 col-lg-4">
                            <div class="card text-center h-100 shadow-sm borrower-card bg-white <?php echo e($rankClass); ?>">
                                <div class="card-body p-4 d-flex flex-column align-items-center">

                                    <div class="reader-avatar-container">
                                        <div class="rank-badge"><?php echo $rankIcon; ?></div>

                                        <?php if($borrower->profile_photo): ?>
                                            <img src="<?php echo e(asset('storage/' . $borrower->profile_photo)); ?>" alt="<?php echo e($borrower->name); ?>" class="avatar mb-3">
                                        <?php else: ?>
                                            <div class="avatar avatar-placeholder mb-3">
                                                <?php echo e(strtoupper(substr($borrower->name, 0, 2))); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <h5 class="card-title fw-bold text-danger mb-1 text-truncate w-100" title="<?php echo e($borrower->name); ?>">
                                        <?php echo e($borrower->name); ?>

                                    </h5>

                                    <div class="mb-3">
                                        <?php if($borrower->role === 'siswa'): ?>
                                            <?php if($borrower->class == 'Lulus'): ?>
                                                <span class="badge bg-secondary text-uppercase tracking-wide">Alumni</span>
                                            <?php elseif(!empty($borrower->class) && !empty($borrower->major)): ?>
                                                <span class="text-muted small"><?php echo e($borrower->class); ?> <?php echo e($borrower->major); ?></span>
                                            <?php elseif(!empty($borrower->class_name)): ?>
                                                <span class="text-muted small"><?php echo e($borrower->class_name); ?></span>
                                            <?php else: ?>
                                                <span class="text-muted small fst-italic">Siswa Aktif</span>
                                            <?php endif; ?>
                                        <?php elseif($borrower->role === 'guru'): ?>
                                            <span class="badge bg-info text-dark">Guru</span>
                                        <?php else: ?>
                                            <span class="text-muted small">Anggota</span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="stats w-100 border-top pt-3 mt-auto">
                                        <div>
                                            <div class="fw-bolder fs-3 text-primary lh-1"><?php echo e($borrower->borrowings_count); ?></div>
                                            <div class="small text-muted text-uppercase fw-bold" style="font-size: 0.7rem; letter-spacing: 1px;">Buku Dipinjam</div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        
        <div class="bg-white py-5 mt-5 shadow-sm">
            <div class="container">
                <div class="text-center mb-5" data-aos="fade-up">
                    <h2 class="fw-bold display-6">TENTANG KAMI</h2>
                </div>
                <div class="row" data-aos="fade-up" data-aos-delay="100">
                    <div class="col-lg-6 mb-4 mb-lg-0">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3964.691893162832!2d106.81866667499214!3d-6.433608393557545!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ea2635732523%3A0x20126f5d1f77c9b0!2sSMK%20Multicomp%20Depok!5e0!3m2!1sid!2sid!4v1762216376908!5m2!1sid!2sid" style="border:0; width: 100%; min-height: 450px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    <div class="col-lg-6">
                        <div class="info-block d-flex align-items-start mb-4">
                            <div class="info-icon"><i class="bi bi-geo-alt-fill"></i></div>
                            <div class="info-text"><h4 class="info-title">Alamat</h4><p>Jl. Raya Kalimulya, Kp. Kebun Duren, No.7, Kel. Kalimulya, Kec. Cilodong, Depok, Jawa Barat, Indonesia.<br>Kode Pos: 16413</p></div>
                        </div>
                        <div class="info-block d-flex align-items-start mb-4">
                            <div class="info-icon"><i class="bi bi-envelope-fill"></i></div>
                            <div class="info-text"><h4 class="info-title">Email</h4><p>smk_multikomp@yahoo.co.id</p></div>
                        </div>
                        <div class="info-block d-flex align-items-start mb-4">
                            <div class="info-icon"><i class="bi bi-telephone-fill"></i></div>
                            <div class="info-text"><h4 class="info-title">Telepon</h4><p>Tlp. (021) 77823607</p></div>
                        </div>
                        <div class="info-block d-flex align-items-start mb-4">
                            <div class="info-icon"><i class="bi bi-clock-fill"></i></div>
                            <div class="info-text"><h4 class="info-title">Jam Buka Perpustakaan</h4><p>Senin - Jumat = 08:00-14:00 WIB</div>
                        </div>
                    </div>
                </div>
                <h4 class="text-center fw-bold mt-5 text-muted" data-aos="fade-up" data-aos-delay="200" style="font-size: 1.1rem; letter-spacing: 1px;">UPT PERPUSTAKAAN MULTICOMP</h4>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({ duration: 800, once: true, offset: 100 });
    </script>

    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/public/catalog/index.blade.php ENDPATH**/ ?>