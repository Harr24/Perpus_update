

<?php $__env->startSection('content'); ?>


<style>
    .profile-card {
        border-radius: 12px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        border: none;
    }
    .profile-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
    }
    .profile-photo {
        width: 120px;
        height: 120px;
        object-fit: cover;
        border-radius: 50%;
        border: 4px solid white;
        box-shadow: 0 4px 15px rgba(0,0,0,0.15);
    }
    .profile-details {
        font-size: 0.95rem;
    }
    .profile-details .label {
        font-weight: 600;
        min-width: 80px;
        display: inline-block;
    }
</style>

<div class="container py-5">

    
    
    
    <div class="row justify-content-center mb-5">
        <div class="col-lg-10 col-xl-8">
            <div class="mb-3">
                <a href="<?php echo e(route('catalog.index')); ?>" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Kembali ke Beranda
                </a>
            </div>

            <div class="text-center">
                <h1 class="display-5 fw-bold">Profil Pustakawan & Staf</h1>
                <p class="lead text-muted">Kenali lebih dekat tim di balik Perpustakaan SMK Multicomp Depok.</p>
            </div>
        </div>
    </div>
    
    
    

    <div class="row g-4 justify-content-center">
        <?php $__empty_1 = true; $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-sm h-100 profile-card">
                    
                    
                    
                    <div class="card-body p-4 d-sm-flex align-items-sm-center text-center text-sm-start">
                        <div class="flex-shrink-0 me-sm-4 mb-3 mb-sm-0">
                            <?php if($person->profile_photo): ?>
                                <img src="<?php echo e(asset('storage/' . $person->profile_photo)); ?>" alt="Foto <?php echo e($person->name); ?>" class="profile-photo">
                            <?php else: ?>
                                <div class="profile-photo d-flex align-items-center justify-content-center bg-danger text-white fs-1 fw-bold mx-auto">
                                    <?php echo e(strtoupper(substr($person->name, 0, 1))); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="profile-details">
                            <h5 class="fw-bold mb-2"><?php echo e($person->name); ?></h5>
                            <p class="mb-1">
                                <span class="label">Jabatan</span>: 
                                <?php if($person->role == 'petugas'): ?>
                                    Pustakawan
                                <?php elseif($person->role == 'guru'): ?>
                                    Guru
                                <?php endif; ?>
                            </p>
                            <p class="mb-0">
                                <span class="label">Surel</span>: <?php echo e($person->email); ?>

                            </p>
                        </div>
                    </div>
                    
                    
                    
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-warning text-center">
                    Data pustakawan dan staf belum tersedia.
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/public/librarians.blade.php ENDPATH**/ ?>