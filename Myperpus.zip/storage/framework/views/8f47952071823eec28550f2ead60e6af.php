


<a class="nav-item" href="<?php echo e(route('catalog.index')); ?>">
    <div class="nav-item-main">
        <span>Lihat Katalog Buku</span>
    </div>
    <span class="meta">Mulai Meminjam</span>
</a>




<a class="nav-item" href="<?php echo e(route('profile.show')); ?>">
    <div class="nav-item-main">
        <span>Lihat Profil Saya</span>
    </div>
    <span class="meta">Akun</span>
</a>


<?php if($hasBorrowings ?? true): ?> 
<a class="nav-item" href="<?php echo e(route('borrow.history')); ?>">
    <div class="nav-item-main">
        <span>Lihat Riwayat Peminjaman</span>
    </div>
    <span class="meta">Riwayat</span>
</a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/dashboard-partials/member.blade.php ENDPATH**/ ?>