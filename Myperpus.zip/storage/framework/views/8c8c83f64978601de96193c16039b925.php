<?php $__env->startSection('content'); ?>
<div class="p-4 md:p-8 min-h-screen" style="background-color: #F8F9FA;">

    
    <div class="mb-6">
        <a href="<?php echo e(route('siswa.katalog')); ?>" class="inline-flex items-center text-sm font-semibold text-gray-500 hover:text-indigo-600 transition-colors">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Kembali ke Katalog
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="mb-4 p-4 text-emerald-700 bg-emerald-100 rounded-xl border border-emerald-200">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="mb-4 p-4 text-red-700 bg-red-100 rounded-xl border border-red-200">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 md:p-10 flex flex-col md:flex-row gap-8 lg:gap-12">

        
        <div class="w-full md:w-1/3 lg:w-1/4 shrink-0">
            <div class="rounded-2xl overflow-hidden shadow-md bg-gray-100 aspect-[3/4]">
                <img src="<?php echo e($book->cover_image ? asset('storage/' . $book->cover_image) : 'https://placehold.co/300x450/E91E63/FFFFFF?text=No+Cover'); ?>"
                     alt="Sampul <?php echo e($book->title); ?>"
                     class="w-full h-full object-cover">
            </div>
        </div>

        
        <div class="w-full flex-1">
            <h1 class="text-3xl font-extrabold text-gray-900 leading-tight mb-2"><?php echo e($book->title); ?></h1>
            <p class="text-lg text-gray-500 font-medium mb-4">oleh <?php echo e($book->author); ?></p>

            <div class="flex flex-wrap items-center gap-2 mb-6">
                <span class="px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-700 tracking-wide uppercase"><?php echo e($book->genre->name); ?></span>

                <?php switch($book->book_type):
                    case ('paket'): ?>
                        <span class="px-3 py-1 rounded-full text-xs font-bold bg-indigo-100 text-indigo-700 tracking-wide uppercase">Buku Paket</span>
                        <?php break; ?>
                    <?php case ('laporan'): ?>
                        <span class="px-3 py-1 rounded-full text-xs font-bold bg-gray-200 text-gray-700 tracking-wide uppercase">Buku Laporan</span>
                        <?php break; ?>
                    <?php case ('reguler'): ?>
                        <span class="px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-700 tracking-wide uppercase">Buku Reguler</span>
                        <?php break; ?>
                <?php endswitch; ?>

                <span class="px-3 py-1 rounded-full text-xs font-bold border border-gray-200 text-gray-600 bg-gray-50 flex items-center gap-1">
                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                    Rak: <?php echo e(optional($book->shelf)->name ?? 'Belum Diatur'); ?>

                </span>
            </div>

            <?php if($book->synopsis): ?>
                <div class="mb-8">
                    <h3 class="text-sm font-bold text-gray-900 mb-2 uppercase tracking-wider">Sinopsis</h3>
                    <p class="text-gray-600 leading-relaxed text-sm whitespace-pre-wrap"><?php echo nl2br(e($book->synopsis)); ?></p>
                </div>
            <?php endif; ?>

            <hr class="border-gray-100 my-8">

            
            <?php
                $isBookPackage = ($book->book_type == 'paket');
            ?>

            <?php if(Auth::user()->role == 'guru' && $isBookPackage): ?>
                <div class="bg-rose-50 border-2 border-rose-100 rounded-2xl p-6 mb-8">
                    <h3 class="text-lg font-bold text-rose-700 flex items-center gap-2 mb-1">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                        Pinjam Buku Paket (Khusus Guru)
                    </h3>
                    <p class="text-sm text-rose-600/80 mb-4">Anda dapat meminjam beberapa eksemplar buku ini sekaligus untuk kebutuhan kelas.</p>

                    <form action="<?php echo e(route('borrow.store.bulk')); ?>" method="POST" class="flex flex-col sm:flex-row gap-4 items-end">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">

                        <div class="w-full sm:w-1/2">
                            <label for="quantity" class="block text-sm font-bold text-gray-700 mb-1">Jumlah Pinjam (Max: <?php echo e($book->available_copies_count); ?>):</label>
                            <input type="number" name="quantity" id="quantity" min="1" max="<?php echo e($book->available_copies_count); ?>" placeholder="0" required
                                   class="block w-full rounded-xl border-gray-300 border px-4 py-2.5 focus:ring-rose-500 focus:border-rose-500 sm:text-sm shadow-sm outline-none">
                        </div>
                        <div class="w-full sm:w-1/2">
                            <button type="submit" class="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-xl shadow-sm text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500 transition-colors">
                                Ajukan Pinjaman Massal
                            </button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>

            
            <div>
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-bold text-gray-900">Daftar Eksemplar Fisik</h3>
                    <span class="text-sm font-semibold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">Sisa <?php echo e($book->available_copies_count); ?> Tersedia</span>
                </div>

                <div class="overflow-x-auto rounded-2xl border border-gray-100 shadow-sm">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Kode Eksemplar</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $book->copies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $copy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50 transition-colors">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                                        <?php echo e($copy->book_code); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($copy->status == 'tersedia'): ?>
                                            <span class="px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-emerald-100 text-emerald-800">Tersedia</span>
                                        <?php elseif($copy->status == 'pending'): ?>
                                            <span class="px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">Sedang Diajukan</span>
                                        <?php else: ?>
                                            <span class="px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-600">Dipinjam</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <?php if($copy->status == 'tersedia'): ?>
                                            <form action="<?php echo e(route('borrow.store', $copy)); ?>" method="POST" onsubmit="return confirm('Anda yakin ingin meminjam eksemplar ini?');" class="inline-block">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="text-indigo-600 hover:text-indigo-900 font-bold bg-indigo-50 hover:bg-indigo-100 px-4 py-1.5 rounded-lg transition-colors">Pinjam</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-gray-400 font-medium px-4 py-1.5">Tidak Tersedia</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" class="px-6 py-8 text-center text-sm text-gray-500">Tidak ada data fisik buku yang tercatat.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan-multicomp\resources\views/siswa/show.blade.php ENDPATH**/ ?>