<aside class="w-full h-full bg-white flex flex-col border-r border-gray-100">
    <div class="h-24 flex items-center px-8">
        <h1 class="text-xl font-extrabold tracking-tight text-rose-900 uppercase">
            Guru.
        </h1>
    </div>

    <nav class="flex-1 px-4 py-2 space-y-1 overflow-y-auto">
        <span class="block px-4 pb-2 text-[11px] font-bold text-gray-400 tracking-wider uppercase mt-2">Menu Utama</span>

        <a href="{{ route('dashboard') }}" class="flex items-center gap-3 px-4 py-3 rounded-2xl transition {{ request()->is('dashboard') ? 'bg-rose-50 text-rose-600 font-bold' : 'text-gray-500 font-semibold hover:bg-gray-50 hover:text-rose-700' }}">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path></svg>
            Dashboard
        </a>

        <span class="block px-4 pt-6 pb-2 text-[11px] font-bold text-gray-400 tracking-wider uppercase">Pustaka & Materi</span>

        <a href="{{ route('guru.materials.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-2xl transition {{ request()->is('guru/materials*') ? 'bg-rose-50 text-rose-600 font-bold' : 'text-gray-500 font-semibold hover:bg-gray-50 hover:text-rose-700' }}">
            <span class="text-lg">📚</span> Kelola Materi
        </a>

        <a href="{{ route('catalog.index') }}" class="flex items-center gap-3 px-4 py-3 rounded-2xl transition {{ request()->is('catalog*') ? 'bg-rose-50 text-rose-600 font-bold' : 'text-gray-500 font-semibold hover:bg-gray-50 hover:text-rose-700' }}">
            <span class="text-lg">📖</span> Katalog Buku
        </a>

        <span class="block px-4 pt-6 pb-2 text-[11px] font-bold text-gray-400 tracking-wider uppercase">Akun Pribadi</span>

        <a href="{{ route('profile.edit') }}" class="flex items-center gap-3 px-4 py-3 rounded-2xl transition {{ request()->is('profile*') ? 'bg-rose-50 text-rose-600 font-bold' : 'text-gray-500 font-semibold hover:bg-gray-50 hover:text-rose-700' }}">
            <span class="text-lg">⚙️</span> Profil Saya
        </a>
    </nav>

    <div class="p-4 border-t border-gray-100">
        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button type="submit" class="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-gray-500 font-semibold hover:bg-red-50 hover:text-red-600 transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                Log out
            </button>
        </form>
    </div>
</aside>
